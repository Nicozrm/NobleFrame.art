function registerBand(level) {
  if (level <= 1) return 0;
  if (level <= 3) return 1;
  return 2;
}
const REGISTER = {
  boot: [
    "REGULATOR: ONLINE. Feld: aktiv.",
    "Der Regulator erwacht zuerst. Das Feld \xF6ffnet sich.",
    "Zuerst erwacht der W\xE4chter \u2014 sodann entfaltet sich das Feld in seiner G\xE4nze."
  ],
  inscribed: [
    "Eintrag: +1.",
    "Die Inschrift ist im Ledger versiegelt.",
    "Die Inschrift ward dem ewigen Ledger anvertraut."
  ],
  vetoPrefix: [
    "VETO.",
    "Der Regulator hat gesprochen:",
    "Es sprach der W\xE4chter, und sein Wort ist Gesetz:"
  ],
  petitionGranted: [
    "Stufe erh\xF6ht.",
    "Die Petition wurde gew\xE4hrt. Die Schwelle hebt sich.",
    "Gew\xE4hrt \u2014 die Schwelle hebt sich, und mit ihr w\xE4chst die B\xFCrde."
  ],
  petitionDenied: [
    "Abgelehnt. Korruption zu hoch.",
    "Die Petition wurde verweigert. Die Korruption tr\xFCbt das Feld.",
    "Verwehrt \u2014 zu tief frisst die Korruption am Gef\xFCge, als dass mehr Macht gew\xE4hrt w\xFCrde."
  ],
  lowered: [
    "Stufe gesenkt.",
    "Autonomie gesenkt \u2014 gew\xE4hrt ohne Pr\xFCfung.",
    "Die Macht ward zur\xFCckgegeben; solches bedarf keiner Pr\xFCfung."
  ],
  purified: [
    "Reinigung: OK.",
    "Das Reinigungsritual ist vollzogen. Die Korruption weicht.",
    "Das Feld ward gel\xE4utert; die Korruption weicht vor dem Ritus zur\xFCck."
  ],
  stabilized: [
    "Crucible: stabilisiert.",
    "Der Crucible wurde stabilisiert.",
    "Der Tiegel ward gefestigt wider den Zerfall."
  ]
};
function speak(key, level) {
  const band = registerBand(level);
  return (REGISTER[key] ?? ["", "", ""])[band];
}

export { registerBand, REGISTER, speak };
