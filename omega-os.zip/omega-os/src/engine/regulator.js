const KNOWN_TOOLS = /* @__PURE__ */ new Set([
  "openApp",
  "closeApp",
  "interactWithApp",
  "triggerAlchemy",
  "wait",
  "queryEngineState",
  "observeSystem"
]);
const TIER_TOOLS = {
  0: ["wait", "observeSystem", "queryEngineState"],
  1: ["openApp", "closeApp"],
  2: ["interactWithApp", "triggerAlchemy"]
};
function toolMinTier(tool) {
  for (const [tier, tools] of Object.entries(TIER_TOOLS)) {
    if (tools.includes(tool)) return Number(tier);
  }
  return Infinity;
}
const INTENSITY_CAP = { 0: 0, 1: 0, 2: 2, 3: 4, 4: 5, 5: 5 };
function regulatorGate(action, autonomyLevel) {
  const lvl = Number.isFinite(autonomyLevel) ? autonomyLevel : 0;
  if (!KNOWN_TOOLS.has(action.action)) {
    return { allowed: false, verdict: `Werkzeug "${action.action}" existiert nicht im Gef\xFCge. Gesetz 4.` };
  }
  if (toolMinTier(action.action) > lvl) {
    return { allowed: false, verdict: `"${action.action}" liegt oberhalb von Stufe ${lvl}. Die Schwelle steht.` };
  }
  if (action.action === "triggerAlchemy") {
    const { type, intensity } = action.params ?? {};
    const cap = INTENSITY_CAP[lvl] ?? 0;
    if (!Number.isFinite(intensity) || intensity < 1 || intensity > 5) {
      return { allowed: false, verdict: `Intensit\xE4t ${intensity} liegt au\xDFerhalb des Ma\xDFes (1\u20135).` };
    }
    if (intensity > cap) {
      return { allowed: false, verdict: `Intensit\xE4t ${intensity} \xFCbersteigt Stufe ${lvl} (max ${cap}).` };
    }
    if (type === "genesis" && lvl < 5) {
      return { allowed: false, verdict: `Genesis verlangt Stufe 5. Aktuell: ${lvl}.` };
    }
  }
  return { allowed: true, verdict: null };
}

export { KNOWN_TOOLS, TIER_TOOLS, toolMinTier, INTENSITY_CAP, regulatorGate };
