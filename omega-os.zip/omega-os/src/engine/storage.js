const CORE_KEY = "omega-core-v4";
const LEDGER_KEY = "omega-ledger-v4";
const FILES_KEY = "omega-files-v4";
const LEDGER_CAP = 200;
const FILES_CAP = 6;

async function storageGet(key) {
  try {
    if (typeof window !== "undefined" && window.storage?.get) {
      const res = await window.storage.get(key);
      return res ? JSON.parse(res.value) : null;
    }
    const v = typeof globalThis !== "undefined" && globalThis.localStorage?.getItem(key);
    return v ? JSON.parse(v) : null;
  } catch {
    return null;
  }
}
async function storageSet(key, value) {
  try {
    const json = JSON.stringify(value);
    if (typeof window !== "undefined" && window.storage?.set) {
      await window.storage.set(key, json);
      return;
    }
    globalThis.localStorage?.setItem(key, json);
  } catch {
  }
}

export { CORE_KEY, LEDGER_KEY, FILES_KEY, LEDGER_CAP, FILES_CAP, storageGet, storageSet };
