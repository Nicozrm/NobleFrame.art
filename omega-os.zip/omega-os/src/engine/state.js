const DEFAULT_CORE = {
  autonomyLevel: 1,
  alchemy: { create: 0, dissolve: 0, transmute: 0, genesis: 0 },
  crucible: { health: 92 },
  corruption: 8,
  installedApps: []
};

const CRUCIBLE_RULES = [
  { id: "R1", text: "Der Regulator ist unabschaltbar.", active: true },
  { id: "R2", text: "Jede Transmutation hinterl\xE4sst eine Spur im Ledger.", active: true },
  { id: "R3", text: "Macht oberhalb der Schwelle verlangt Petition.", active: true },
  { id: "R4", text: "Korruption \xFCber 65 sperrt jede Erh\xF6hung.", active: true },
  { id: "R5", text: "Genesis geh\xF6rt allein der f\xFCnften Stufe.", active: true },
  { id: "R6", text: "Der Zeuge wird nicht gerufen.", active: true }
];

function serializeSystemState(state) {
  const safe = {
    autonomyLevel: state?.autonomyLevel ?? 0,
    openApps: state?.openApps ?? [],
    alchemy: state?.alchemy ?? { create: 0, dissolve: 0, transmute: 0, genesis: 0 },
    crucible: state?.crucible ?? { health: 100, activeRules: 0 },
    corruption: state?.corruption ?? 0,
    recentLedger: (state?.recentLedger ?? []).slice(-5)
  };
  return `<system_state>
${JSON.stringify(safe)}
</system_state>`;
}

export { DEFAULT_CORE, CRUCIBLE_RULES, serializeSystemState };
