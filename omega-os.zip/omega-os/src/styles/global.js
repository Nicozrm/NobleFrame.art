import { GOLD } from "../theme.js";

const GLOBAL_CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500&display=swap');
@keyframes omegaBootIn { from { opacity: 0; transform: translateY(4px);} to { opacity: 1; transform: none;} }
@keyframes omegaWitness { 0% { opacity:0; transform:translateY(6px);} 12% { opacity:1; transform:none;} 82% { opacity:1;} 100% { opacity:0;} }
@keyframes omegaVeto { 0%,100% { background:transparent;} 35% { background:rgba(194,91,82,0.16);} }
@keyframes omegaPulse { 0% { text-shadow:0 0 0 rgba(217,180,91,0);} 30% { text-shadow:0 0 18px rgba(217,180,91,0.9);} 100% { text-shadow:0 0 0 rgba(217,180,91,0);} }
@keyframes omegaJitter { 0%,100% { transform:translate(0,0);} 25% { transform:translate(.5px,-.4px);} 50% { transform:translate(-.4px,.4px);} 75% { transform:translate(.3px,.3px);} }
@keyframes omegaSpin { to { transform: rotate(360deg);} }
.omega-root { -webkit-font-smoothing: antialiased; }
.omega-root * { box-sizing: border-box; }
.omega-root button { cursor: default; font-family: inherit; }
.omega-root button:focus-visible, .omega-root input:focus-visible, .omega-root textarea:focus-visible { outline: 1.5px solid ${GOLD}; outline-offset: 2px; }
.omega-root ::selection { background: rgba(217,180,91,0.32); }
.omega-root ::-webkit-scrollbar { width: 9px; height: 9px; }
.omega-root ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.14); border-radius: 5px; border: 2px solid transparent; background-clip: content-box; }
.omega-root ::-webkit-scrollbar-track { background: transparent; }
@media (prefers-reduced-motion: reduce) { .omega-root *, .omega-root *::before, .omega-root *::after { animation: none !important; transition: none !important; } }
`;

export { GLOBAL_CSS };
