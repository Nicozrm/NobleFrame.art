import React, { useState } from "react";
import { WIN_BG, TITLE_BG, HAIRLINE_SOFT, TL_RED, TL_YELLOW, TL_GREEN, TL_IDLE, GOLD, FONT_DISPLAY, TEXT_TER, MENUBAR_H } from "../theme.js";

function MacWindow({ win, meta, focused, onFocus, onClose, onMin, onZoom, onGesture, children }) {
  const [lightsHover, setLightsHover] = useState(false);
  return <div
    onPointerDown={(e) => {
      e.stopPropagation();
      onFocus();
    }}
    style={{
      position: "absolute",
      left: win.x,
      top: win.y - MENUBAR_H,
      width: win.w,
      height: win.h,
      zIndex: win.z,
      display: "flex",
      flexDirection: "column",
      borderRadius: 12,
      overflow: "hidden",
      background: WIN_BG,
      backdropFilter: "blur(26px)",
      WebkitBackdropFilter: "blur(26px)",
      border: `1px solid ${focused ? "rgba(255,255,255,0.12)" : HAIRLINE_SOFT}`,
      boxShadow: focused ? "0 28px 80px rgba(0,0,0,0.62), 0 2px 10px rgba(0,0,0,0.4)" : "0 16px 44px rgba(0,0,0,0.45)",
      maxWidth: "96vw",
      maxHeight: "86vh"
    }}
  >
      <div
    onPointerDown={(e) => {
      e.stopPropagation();
      onGesture(e, win.id, "move");
    }}
    onDoubleClick={onZoom}
    style={{ height: 38, flexShrink: 0, display: "flex", alignItems: "center", padding: "0 12px", background: focused ? TITLE_BG : "rgba(36,36,38,0.4)", borderBottom: `1px solid ${HAIRLINE_SOFT}`, touchAction: "none", cursor: "default" }}
  >
        <div
    onPointerDown={(e) => e.stopPropagation()}
    onMouseEnter={() => setLightsHover(true)}
    onMouseLeave={() => setLightsHover(false)}
    style={{ display: "flex", gap: 8 }}
  >
          <TrafficLight color={focused ? TL_RED : TL_IDLE} symbol="✕" show={lightsHover} onClick={onClose} label="Schließen" />
          <TrafficLight color={focused ? TL_YELLOW : TL_IDLE} symbol="−" show={lightsHover} onClick={onMin} label="Minimieren" />
          <TrafficLight color={focused ? TL_GREEN : TL_IDLE} symbol="⤢" show={lightsHover} onClick={onZoom} label="Zoomen" />
        </div>
        <div style={{ flex: 1, textAlign: "center", fontSize: 13, fontWeight: 600, color: focused ? "#E8E8EC" : TEXT_TER, display: "flex", alignItems: "center", justifyContent: "center", gap: 7, paddingRight: 56 }}>
          <span style={{ color: focused ? GOLD : TEXT_TER, fontFamily: FONT_DISPLAY, fontSize: 14 }}>{meta.glyph}</span>{meta.title}
        </div>
      </div>
      <div style={{ flex: 1, overflow: "hidden", position: "relative" }}>{children}</div>
      {!win.max && <div
    onPointerDown={(e) => {
      e.stopPropagation();
      onGesture(e, win.id, "resize");
    }}
    title="Größe ändern"
    style={{ position: "absolute", right: 0, bottom: 0, width: 16, height: 16, cursor: "nwse-resize", touchAction: "none" }}
  />}
    </div>;
}
function TrafficLight({ color, symbol, show, onClick, label }) {
  return <button
    onClick={onClick}
    aria-label={label}
    style={{ width: 12, height: 12, borderRadius: "50%", background: color, border: "1px solid rgba(0,0,0,0.25)", padding: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 8.5, lineHeight: 1, color: "rgba(0,0,0,0.55)", fontWeight: 700 }}
  >
      {show ? symbol : ""}
    </button>;
}

export { MacWindow, TrafficLight };
