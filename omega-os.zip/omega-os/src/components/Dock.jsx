import React, { useState, useRef } from "react";
import { GOLD, HAIRLINE, FONT_DISPLAY } from "../theme.js";
import { appMeta, STORE_BY_ID } from "../data/apps.js";

function Dock({ apps, openApps, onLaunch }) {
  const [mouseX, setMouseX] = useState(null);
  const dockRef = useRef(null);
  const centers = useRef(/* @__PURE__ */ new Map());
  const scaleFor = (app) => {
    if (mouseX == null) return 1;
    const cx = centers.current.get(app);
    if (cx == null) return 1;
    const dist = Math.abs(mouseX - cx);
    const radius = 110;
    if (dist > radius) return 1;
    const t = 1 - dist / radius;
    return 1 + 0.62 * (t * t * (3 - 2 * t));
  };
  return <div style={{ position: "absolute", left: 0, right: 0, bottom: 10, display: "flex", justifyContent: "center", zIndex: 4e3 }}>
      <div
    ref={dockRef}
    onPointerMove={(e) => setMouseX(e.clientX)}
    onPointerLeave={() => setMouseX(null)}
    style={{ display: "flex", alignItems: "flex-end", gap: 9, padding: "9px 14px", borderRadius: 20, background: "rgba(30,30,34,0.55)", backdropFilter: "blur(30px)", WebkitBackdropFilter: "blur(30px)", border: `1px solid ${HAIRLINE}`, boxShadow: "0 22px 60px rgba(0,0,0,0.55)", height: 78 }}
  >
        {apps.map((app, idx) => {
    const meta = appMeta(app);
    const s = scaleFor(app);
    const isOpen = openApps.includes(app);
    const isStoreApp = !!STORE_BY_ID[app];
    const firstStore = isStoreApp && apps.findIndex((a) => STORE_BY_ID[a]) === idx;
    return <React.Fragment key={app}>
              {firstStore && <div style={{ width: 1, alignSelf: "stretch", margin: "6px 3px", background: HAIRLINE }} />}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
                <button
      ref={(el) => {
        if (el) {
          const r = el.getBoundingClientRect();
          centers.current.set(app, r.left + r.width / 2);
        }
      }}
      onClick={() => onLaunch(app)}
      title={meta.title}
      style={{
        width: 44 * s,
        height: 44 * s,
        borderRadius: 11 * s,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 21 * s,
        fontFamily: FONT_DISPLAY,
        color: GOLD,
        background: "linear-gradient(180deg, rgba(255,255,255,0.10), rgba(255,255,255,0.03))",
        border: `1px solid ${HAIRLINE}`,
        boxShadow: "0 6px 16px rgba(0,0,0,0.4)",
        transition: mouseX == null ? "all 260ms ease" : "all 70ms ease-out",
        transformOrigin: "bottom center"
      }}
    >
                  {meta.glyph}
                </button>
                <span style={{ width: 3.5, height: 3.5, borderRadius: "50%", background: isOpen ? "#D2D2D6" : "transparent" }} />
              </div>
            </React.Fragment>;
  })}
      </div>
    </div>;
}

export { Dock };
