import React, { useState } from "react";
import { GOLD_BTN, GOLD_BTN_HOVER, INK_ON_GOLD, HAIRLINE, BLOOD, VERDIGRIS } from "../theme.js";

function GoldButton({ label, onClick, disabled, variant = "gold", small, icon }) {
  const [hover, setHover] = useState(false);
  const palette = {
    gold: { bg: hover && !disabled ? GOLD_BTN_HOVER : GOLD_BTN, fg: INK_ON_GOLD, bd: "transparent" },
    ghost: { bg: hover && !disabled ? "rgba(255,255,255,0.10)" : "rgba(255,255,255,0.06)", fg: "#E6E6EA", bd: HAIRLINE },
    blood: { bg: "transparent", fg: BLOOD, bd: "rgba(194,91,82,0.5)" },
    verdigris: { bg: "transparent", fg: VERDIGRIS, bd: "rgba(94,154,135,0.5)" }
  }[variant];
  return <button
    onClick={onClick}
    disabled={disabled}
    onMouseEnter={() => setHover(true)}
    onMouseLeave={() => setHover(false)}
    style={{ padding: small ? "4px 12px" : "7px 16px", borderRadius: 999, fontSize: small ? 12 : 12.5, fontWeight: 600, background: palette.bg, color: palette.fg, border: `1px solid ${palette.bd}`, opacity: disabled ? 0.45 : 1, display: "inline-flex", alignItems: "center", gap: 5, transition: "background 140ms ease" }}
  >
      {icon && <span style={{ fontSize: small ? 11 : 12 }}>{icon}</span>}{label}
    </button>;
}

export { GoldButton };
