import React, { useState } from "react";
import { GOLD, INK_ON_GOLD, HAIRLINE_SOFT } from "../theme.js";

function DesktopIcon({ label, glyph, onOpen }) {
  const [selected, setSelected] = useState(false);
  return <div
    onPointerDown={(e) => e.stopPropagation()}
    onClick={() => {
      if (selected) onOpen();
      else setSelected(true);
    }}
    onBlur={() => setSelected(false)}
    tabIndex={0}
    style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, width: 76, cursor: "default", outline: "none" }}
  >
      <div style={{ width: 50, height: 50, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, color: GOLD, background: selected ? "rgba(217,180,91,0.18)" : "rgba(255,255,255,0.05)", border: `1px solid ${selected ? "rgba(217,180,91,0.45)" : HAIRLINE_SOFT}`, boxShadow: "0 8px 22px rgba(0,0,0,0.4)" }}>
        {glyph}
      </div>
      <div style={{ fontSize: 11.5, color: "#E4E4E8", textShadow: "0 1px 3px rgba(0,0,0,0.8)", padding: "1px 6px", borderRadius: 4, background: selected ? "rgba(217,180,91,0.85)" : "transparent", ...selected ? { color: INK_ON_GOLD } : {} }}>
        {label}
      </div>
    </div>;
}

export { DesktopIcon };
