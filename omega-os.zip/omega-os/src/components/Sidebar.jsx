import React from "react";
import { GOLD, GOLD_SOFT, BLOOD, CARD_BG, HAIRLINE_SOFT, TEXT_SEC, FONT_DISPLAY, MENUBAR_H } from "../theme.js";
import { clamp } from "../lib/utils.js";
import { appMeta } from "../data/apps.js";

function SideCard({ children, style }) {
  return <div style={{ background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 12, padding: "12px 14px", backdropFilter: "blur(18px)", WebkitBackdropFilter: "blur(18px)", ...style }}>{children}</div>;
}
function SideLabel({ children }) {
  return <div style={{ fontSize: 10, letterSpacing: "0.22em", color: GOLD_SOFT, fontWeight: 700, marginBottom: 8 }}>{children}</div>;
}
function StatBar({ label, value, suffix = "%" }) {
  return <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 7 }}>
      <span style={{ width: 30, fontSize: 10.5, color: TEXT_SEC, letterSpacing: "0.06em" }}>{label}</span>
      <div style={{ flex: 1, height: 4, borderRadius: 2, background: "rgba(255,255,255,0.08)" }}>
        <div style={{ width: `${clamp(value, 0, 100)}%`, height: "100%", borderRadius: 2, background: `linear-gradient(90deg, ${GOLD_SOFT}, ${GOLD})`, transition: "width 900ms ease" }} />
      </div>
      <span style={{ width: 34, textAlign: "right", fontSize: 11, color: "#D6D6DA", fontVariantNumeric: "tabular-nums" }}>{value}{suffix}</span>
    </div>;
}
function Sidebar({ now, stats, windows, focusedApp, onFocusApp, corruption, jitter }) {
  const time = new Intl.DateTimeFormat("de-DE", { hour: "2-digit", minute: "2-digit" }).format(now);
  const date = new Intl.DateTimeFormat("de-DE", { weekday: "long", day: "numeric", month: "long" }).format(now);
  return <div style={{ position: "absolute", right: 16, top: MENUBAR_H + 16, width: 248, display: "flex", flexDirection: "column", gap: 14, zIndex: 2, pointerEvents: "auto" }}>
      <SideCard>
        <div style={{ fontFamily: FONT_DISPLAY, fontSize: 42, color: "#EDE6D2", lineHeight: 1, animation: jitter ? "omegaJitter 300ms steps(2) infinite" : "none" }}>{time}</div>
        <div style={{ marginTop: 6, fontSize: 11.5, color: TEXT_SEC }}>{date}</div>
      </SideCard>
      <SideCard>
        <SideLabel>SYSTEM</SideLabel>
        <StatBar label="CPU" value={stats.cpu} />
        <StatBar label="RAM" value={stats.ram} />
        <StatBar label="NET" value={stats.net} suffix="" />
        {corruption >= 40 && <div style={{ marginTop: 6, fontSize: 10, color: corruption >= 65 ? BLOOD : GOLD_SOFT }}>field corruption · {corruption}</div>}
      </SideCard>
      <SideCard>
        <SideLabel>WINDOWS</SideLabel>
        <div style={{ fontFamily: FONT_DISPLAY, fontSize: 26, color: "#EDE6D2", lineHeight: 1 }}>{windows.filter((w) => !w.min).length}</div>
        <div style={{ marginTop: 6, display: "flex", flexDirection: "column", gap: 3 }}>
          {windows.slice(0, 5).map((w) => <div key={w.id} onClick={() => onFocusApp(w.id)} style={{ fontSize: 11, color: w.app === focusedApp ? GOLD : TEXT_SEC, cursor: "pointer" }}>
              {w.app === focusedApp ? "focus \xB7 " : w.min ? "min \xB7 " : "\xB7 "}{appMeta(w.app).title}
            </div>)}
        </div>
      </SideCard>
      <SideCard>
        <SideLabel>PATCH SIGNAL</SideLabel>
        <div style={{ fontSize: 11.5, color: TEXT_SEC, lineHeight: 1.5 }}>
          Open Patch &amp; wire a Display node — its value appears here live.
        </div>
      </SideCard>
    </div>;
}

export { Sidebar, SideCard, SideLabel, StatBar };
