import React from "react";

function SvgIcon({ d }) {
  return <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#C8C8CC" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d={d} />
    </svg>;
}

export { SvgIcon };
