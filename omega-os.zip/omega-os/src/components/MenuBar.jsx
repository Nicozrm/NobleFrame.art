import React from "react";
import { INK_ON_GOLD, TEXT_PRI, TEXT_TER, GOLD, HAIRLINE, HAIRLINE_SOFT, FONT_DISPLAY, MENUBAR_H } from "../theme.js";
import { appMeta, STORE_APPS } from "../data/apps.js";
import { SvgIcon } from "./SvgIcon.jsx";

function MenuBar({ now, openMenu, setOpenMenu, focusedTitle, windows, autonomy, actions }) {
  const item = (label, onClick, opts) => <div
    key={label}
    onPointerDown={(e) => e.stopPropagation()}
    onClick={() => {
      if (!opts?.disabled && onClick) {
        onClick();
        setOpenMenu(null);
      }
    }}
    style={{ display: "flex", justifyContent: "space-between", gap: 24, padding: "5px 12px", borderRadius: 5, fontSize: 13, color: opts?.disabled ? TEXT_TER : TEXT_PRI, cursor: opts?.disabled ? "default" : "pointer" }}
    onMouseEnter={(e) => {
      if (!opts?.disabled) e.currentTarget.style.background = "rgba(217,180,91,0.85)", e.currentTarget.style.color = INK_ON_GOLD;
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.background = "transparent";
      e.currentTarget.style.color = opts?.disabled ? TEXT_TER : TEXT_PRI;
    }}
  >
      <span>{label}</span>{opts?.shortcut && <span style={{ color: TEXT_TER }}>{opts.shortcut}</span>}
    </div>;
  const sep = (k) => <div key={k} style={{ height: 1, background: HAIRLINE, margin: "5px 8px" }} />;
  const menus = {
    "\u03A9 OMEGA": [
      item("About OMEGA\u2026", () => actions.openApp("About")),
      item("App Store\u2026", () => actions.openApp("AppStore")),
      sep("s1"),
      item("Purify Field", actions.purify),
      item("Stabilize Crucible", actions.stabilize),
      sep("s2"),
      item("Regulator\u2026", () => actions.openApp("Regulator"))
    ],
    "App Store": [
      item("Open App Store", () => actions.openApp("AppStore")),
      sep("s1"),
      ...STORE_APPS.map((a) => item(a.title, () => actions.openApp("AppStore")))
    ],
    "File": [
      item("New Egregore Window", () => actions.openApp("Egregore"), { shortcut: "\u23182" }),
      item("New Terminal", () => actions.openApp("Terminal"), { shortcut: "\u23189" }),
      sep("s1"),
      item("Close Window", actions.closeFocused, { shortcut: "\u2318W" })
    ],
    "Edit": [
      item("Cut", void 0, { disabled: true, shortcut: "\u2318X" }),
      item("Copy", void 0, { disabled: true, shortcut: "\u2318C" }),
      item("Paste", void 0, { disabled: true, shortcut: "\u2318V" })
    ],
    "View": [
      item("Open Ledger", () => actions.openApp("Ledger"), { shortcut: "\u23185" }),
      item("Open Alchemy", () => actions.openApp("Alchemy"), { shortcut: "\u23186" })
    ],
    "Window": [
      item("Minimize", actions.minimizeFocused, { shortcut: "\u2318M" }),
      item("Zoom", actions.zoomFocused),
      sep("s1"),
      ...windows.map((w) => item(`${w.min ? "\u25E6 " : "\u2022 "}${appMeta(w.app).title}`, () => actions.focusWinById(w.id)))
    ]
  };
  const fmtDate = new Intl.DateTimeFormat("de-DE", { weekday: "short", day: "numeric", month: "long" }).format(now);
  const fmtTime = new Intl.DateTimeFormat("de-DE", { hour: "2-digit", minute: "2-digit" }).format(now);
  return <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: MENUBAR_H, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 14px", background: "rgba(18,18,20,0.62)", backdropFilter: "blur(22px)", WebkitBackdropFilter: "blur(22px)", borderBottom: `1px solid ${HAIRLINE_SOFT}`, zIndex: 5e3, fontSize: 13 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 2 }}>
        {Object.keys(menus).map((name, idx) => <div key={name} style={{ position: "relative" }}>
            <div
    onPointerDown={(e) => e.stopPropagation()}
    onClick={() => setOpenMenu(openMenu === name ? null : name)}
    onMouseEnter={() => {
      if (openMenu) setOpenMenu(name);
    }}
    style={{ padding: "3px 10px", borderRadius: 5, fontWeight: idx === 0 ? 700 : 500, color: TEXT_PRI, background: openMenu === name ? "rgba(255,255,255,0.14)" : "transparent", cursor: "default" }}
  >
              {name}
            </div>
            {openMenu === name && <div onPointerDown={(e) => e.stopPropagation()} style={{ position: "absolute", top: MENUBAR_H - 2, left: 0, minWidth: 230, padding: 5, borderRadius: 9, background: "rgba(36,36,40,0.92)", backdropFilter: "blur(28px)", WebkitBackdropFilter: "blur(28px)", border: `1px solid ${HAIRLINE}`, boxShadow: "0 18px 50px rgba(0,0,0,0.55)" }}>
                {menus[name]}
              </div>}
          </div>)}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 14, color: "#D8D8DC" }}>
        <span title={`Autonomie-Stufe ${autonomy}`} style={{ fontFamily: FONT_DISPLAY, color: GOLD, fontSize: 14 }}>Ω{autonomy}</span>
        <SvgIcon d="M3 9.5C5.5 7 8 6 12 6s6.5 1 9 3.5M6 13c1.8-1.6 3.6-2.3 6-2.3s4.2.7 6 2.3M9.2 16.4c.9-.7 1.8-1 2.8-1s1.9.3 2.8 1M12 19.4h.01" />
        <SvgIcon d="M5 9v6h3l4 4V5L8 9H5zM16 9a4 4 0 0 1 0 6" />
        <SvgIcon d="M4 6h16M4 12h16M4 18h10" />
        <span style={{ fontVariantNumeric: "tabular-nums" }}>{fmtDate}&nbsp;&nbsp;{fmtTime}</span>
      </div>
    </div>;
}

export { MenuBar };
