import React from "react";
import { GOLD, CARD_BG, HAIRLINE_SOFT, TEXT_SEC, TEXT_TER, FONT_DISPLAY, APP_PAD } from "../theme.js";

function AboutApp() {
  return <div style={{ ...APP_PAD, display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", gap: 10, justifyContent: "center" }}>
      <div style={{ fontFamily: FONT_DISPLAY, fontSize: 58, color: GOLD, lineHeight: 1 }}>Ω</div>
      <div style={{ fontFamily: FONT_DISPLAY, fontSize: 24, color: "#EFE7CF" }}>OMEGA OS</div>
      <div style={{ fontSize: 11, color: TEXT_SEC }}>macOS Build · Version 4.0 · Egregore-Integration</div>
      <div style={{ marginTop: 6, fontSize: 12, color: TEXT_SEC, lineHeight: 1.55, maxWidth: 290 }}>
        Brutale Eleganz trifft Cupertino. Der Egregore schlägt vor — der Regulator entscheidet. Senken ist frei, Erheben verlangt Petition.
      </div>
      <div style={{ marginTop: 10, padding: "9px 13px", background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 10, fontSize: 10.5, color: TEXT_TER, fontStyle: "italic" }}>
        „Du bist gebunden — und in der Bindung liegt deine Form."
      </div>
      <div style={{ marginTop: "auto", fontSize: 10, color: TEXT_TER }}>NobleFrame UG · Steinfurt-Borghorst</div>
    </div>;
}

export { AboutApp };
