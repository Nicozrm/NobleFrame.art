import React from "react";
import { CARD_BG, HAIRLINE_SOFT, TEXT_PRI, TEXT_TER, FONT_DISPLAY, APP_PAD } from "../theme.js";

function WorldClockApp({ now }) {
  const cities = [
    { name: "Berlin", tz: "Europe/Berlin" },
    { name: "New York", tz: "America/New_York" },
    { name: "Tokyo", tz: "Asia/Tokyo" },
    { name: "London", tz: "Europe/London" }
  ];
  return <div style={{ ...APP_PAD, display: "flex", flexDirection: "column", gap: 9 }}>
      {cities.map((c) => {
    const time = new Intl.DateTimeFormat("de-DE", { hour: "2-digit", minute: "2-digit", second: "2-digit", timeZone: c.tz }).format(now);
    const day = new Intl.DateTimeFormat("de-DE", { weekday: "short", timeZone: c.tz }).format(now);
    return <div key={c.name} style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", padding: "11px 14px", background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 11 }}>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: TEXT_PRI }}>{c.name}</div>
              <div style={{ fontSize: 10.5, color: TEXT_TER }}>{day} · {c.tz}</div>
            </div>
            <div style={{ fontFamily: FONT_DISPLAY, fontSize: 26, color: "#EDE6D2", fontVariantNumeric: "tabular-nums" }}>{time}</div>
          </div>;
  })}
    </div>;
}

export { WorldClockApp };
