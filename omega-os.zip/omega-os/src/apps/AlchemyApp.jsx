import React from "react";
import { GOLD, CARD_BG, HAIRLINE_SOFT, TEXT_SEC, FONT_DISPLAY } from "../theme.js";

const WORKS = [
  { key: "create", label: "COAGULA" },
  { key: "dissolve", label: "SOLVE" },
  { key: "transmute", label: "TRANSMUTATIO" },
  { key: "genesis", label: "GENESIS" }
];
function AlchemyApp({ ctx }) {
  return <div style={{ height: "100%", padding: 14, display: "grid", gridTemplateColumns: "1fr 1fr", gridTemplateRows: "1fr 1fr", gap: 10 }}>
      {WORKS.map((w) => <div key={w.key} style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 12 }}>
          <div key={`${w.key}-${ctx.pulseKey}`} style={{ fontFamily: FONT_DISPLAY, fontSize: 42, color: GOLD, animation: ctx.pulseKey ? "omegaPulse 900ms ease both" : "none" }}>
            {ctx.core.alchemy[w.key] ?? 0}
          </div>
          <div style={{ fontSize: 9, letterSpacing: "0.26em", color: TEXT_SEC, fontWeight: 700 }}>{w.label}</div>
        </div>)}
    </div>;
}

export { AlchemyApp };
