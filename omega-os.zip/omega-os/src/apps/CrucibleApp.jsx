import React from "react";
import { GOLD, GOLD_SOFT, BLOOD, CARD_BG, HAIRLINE_SOFT, TEXT_SEC, TEXT_TER, FONT_DISPLAY, FONT_MONO, APP_PAD } from "../theme.js";
import { CRUCIBLE_RULES } from "../engine/state.js";
import { GoldButton } from "../components/GoldButton.jsx";

function CrucibleApp({ ctx }) {
  const h = ctx.core.crucible.health;
  const barColor = h >= 60 ? GOLD : h >= 30 ? GOLD_SOFT : BLOOD;
  return <div style={{ ...APP_PAD, display: "flex", flexDirection: "column", gap: 14 }}>
      <div>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
          <span style={{ fontSize: 10, letterSpacing: "0.22em", color: TEXT_SEC, fontWeight: 700 }}>GESUNDHEIT</span>
          <span style={{ fontFamily: FONT_DISPLAY, fontSize: 34, color: barColor }}>{h}</span>
        </div>
        <div style={{ marginTop: 5, height: 5, borderRadius: 3, background: "rgba(255,255,255,0.08)" }}>
          <div style={{ width: `${h}%`, height: "100%", borderRadius: 3, background: barColor, transition: "width 500ms, background 500ms" }} />
        </div>
        <div style={{ marginTop: 5, fontSize: 10.5, color: TEXT_TER, fontStyle: "italic" }}>Jede Transmutation zehrt am Gefäß.</div>
      </div>
      <div>
        <div style={{ fontSize: 10, letterSpacing: "0.22em", color: TEXT_SEC, fontWeight: 700, marginBottom: 7 }}>CHARTA · {CRUCIBLE_RULES.length} REGELN AKTIV</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {CRUCIBLE_RULES.map((r) => <div key={r.id} style={{ display: "flex", gap: 9, alignItems: "baseline", padding: "6px 10px", background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 8 }}>
              <span style={{ fontFamily: FONT_MONO, fontSize: 10, color: GOLD_SOFT }}>{r.id}</span>
              <span style={{ fontSize: 12, color: "#E0E0E4" }}>{r.text}</span>
            </div>)}
        </div>
      </div>
      <div style={{ marginTop: "auto" }}>
        <GoldButton label="Stabilisieren (+15)" variant="verdigris" onClick={ctx.stabilizeCrucible} />
      </div>
    </div>;
}

export { CrucibleApp };
