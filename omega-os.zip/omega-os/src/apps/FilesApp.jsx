import React from "react";
import { CARD_BG, HAIRLINE_SOFT, TEXT_PRI, TEXT_SEC, TEXT_TER, FONT_DISPLAY, FONT_MONO, APP_PAD } from "../theme.js";
import { FILES_CAP } from "../engine/storage.js";

function FilesApp({ ctx }) {
  return <div style={{ ...APP_PAD, display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ fontSize: 10, letterSpacing: "0.2em", color: TEXT_SEC, fontWeight: 700 }}>INSCHRIFTEN · {ctx.paintFiles.length}/{FILES_CAP}</div>
      {ctx.paintFiles.length === 0 ? <div style={{ fontFamily: FONT_DISPLAY, fontStyle: "italic", fontSize: 14.5, color: TEXT_TER }}>Noch keine Dateien — erschaffe etwas in Paint.</div> : <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 10 }}>
          {ctx.paintFiles.map((f) => <div key={f.ts} style={{ background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 10, overflow: "hidden" }}>
              <img src={f.dataUrl} alt={f.name} style={{ width: "100%", height: 86, objectFit: "cover", display: "block" }} />
              <div style={{ padding: "7px 9px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 6 }}>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 11.5, color: TEXT_PRI, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{f.name}</div>
                  <div style={{ fontSize: 9, color: TEXT_TER, fontFamily: FONT_MONO }}>{new Date(f.ts).toLocaleTimeString("de-DE")}</div>
                </div>
                <button onClick={() => ctx.deletePaintFile(f.ts)} title="Dem Void zurückgeben" style={{ background: "transparent", border: "none", color: TEXT_TER, fontSize: 13 }}>✕</button>
              </div>
            </div>)}
        </div>}
    </div>;
}

export { FilesApp };
