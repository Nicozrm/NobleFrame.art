import React, { useState, useRef, useEffect } from "react";
import { GOLD, GOLD_SOFT, CARD_BG, HAIRLINE_SOFT, TEXT_PRI, TEXT_SEC, TEXT_TER, FONT_DISPLAY, FONT_MONO, FONT_SYS } from "../theme.js";
import { GoldButton } from "../components/GoldButton.jsx";

function EgregoreApp({ ctx }) {
  const [input, setInput] = useState("");
  const scrollRef = useRef(null);
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [ctx.egregoreLog.length, ctx.egregoreBusy]);
  const send = () => {
    const text = input.trim();
    if (!text || ctx.egregoreBusy) return;
    setInput("");
    void ctx.summonEgregore(text);
  };
  return <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: "14px 14px 8px", display: "flex", flexDirection: "column", gap: 11 }}>
        {ctx.egregoreLog.map((m, i) => {
    if (m.role === "user") return <div key={i} style={{ alignSelf: "flex-end", maxWidth: "84%", padding: "7px 12px", borderRadius: "14px 14px 4px 14px", background: "rgba(217,180,91,0.14)", border: "1px solid rgba(217,180,91,0.22)", fontSize: 13, color: "#F0EBDD" }}>{m.text}</div>;
    if (m.role === "system") return <div key={i} style={{ alignSelf: "center", fontSize: 11, fontStyle: "italic", color: TEXT_TER }}>— {m.text} —</div>;
    return <div key={i} style={{ alignSelf: "flex-start", maxWidth: "92%" }}>
              <div style={{ padding: "8px 12px", borderRadius: "14px 14px 14px 4px", background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderLeft: `2px solid ${GOLD_SOFT}`, fontFamily: FONT_DISPLAY, fontSize: 15.5, lineHeight: 1.45, color: "#ECE8DC" }}>{m.text}</div>
              {m.thinking ? <details style={{ marginTop: 4, marginLeft: 2 }}>
                  <summary style={{ fontSize: 9.5, letterSpacing: "0.18em", color: TEXT_TER, cursor: "pointer", listStyle: "none", fontWeight: 700 }}>PROTOKOLL ▸</summary>
                  <pre style={{ marginTop: 4, padding: "8px 10px", whiteSpace: "pre-wrap", fontFamily: FONT_MONO, fontSize: 10, color: TEXT_SEC, background: "rgba(0,0,0,0.35)", border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 8 }}>{m.thinking}</pre>
                </details> : null}
            </div>;
  })}
        {ctx.egregoreBusy && <div style={{ alignSelf: "flex-start", fontFamily: FONT_DISPLAY, fontStyle: "italic", fontSize: 13.5, color: GOLD_SOFT }}>
            Der Egregore wirkt<span style={{ display: "inline-block", animation: "omegaPulse 1.4s ease infinite" }}> …</span>
          </div>}
      </div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 8, padding: "10px 12px", borderTop: `1px solid ${HAIRLINE_SOFT}`, background: "rgba(0,0,0,0.18)" }}>
        <textarea
    value={input}
    onChange={(e) => setInput(e.target.value)}
    onKeyDown={(e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    }}
    rows={1}
    placeholder="Sprich zum Egregore…"
    style={{ flex: 1, resize: "none", padding: "8px 12px", borderRadius: 10, background: "rgba(255,255,255,0.06)", border: `1px solid ${HAIRLINE_SOFT}`, color: TEXT_PRI, fontSize: 13, fontFamily: FONT_SYS, outline: "none" }}
  />
        <GoldButton label="Beschwören" onClick={send} disabled={ctx.egregoreBusy} />
      </div>
    </div>;
}

export { EgregoreApp };
