import React from "react";
import { GOLD, BLOOD, VERDIGRIS, CARD_BG, HAIRLINE_SOFT, TEXT_SEC, TEXT_TER, FONT_DISPLAY, FONT_MONO } from "../theme.js";

const TONE_COLOR = { gold: GOLD, blood: BLOOD, verdigris: VERDIGRIS, dim: TEXT_SEC };
function LedgerApp({ ctx }) {
  const entries = [...ctx.ledger].reverse();
  return <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ padding: "9px 16px", borderBottom: `1px solid ${HAIRLINE_SOFT}`, fontSize: 10, letterSpacing: "0.2em", color: TEXT_SEC, fontWeight: 700 }}>
        {ctx.ledger.length} INSCHRIFTEN · PERSISTENT
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "12px 16px", display: "flex", flexDirection: "column", gap: 7 }}>
        {entries.length === 0 && <div style={{ fontFamily: FONT_DISPLAY, fontStyle: "italic", fontSize: 14.5, color: TEXT_TER }}>Das Ledger ist leer. Noch wurde nichts gewirkt.</div>}
        {entries.map((e, i) => <div key={i} style={{ padding: "7px 10px", background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderLeft: `2px solid ${TONE_COLOR[e.tone] ?? TEXT_SEC}`, borderRadius: 8 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontFamily: FONT_MONO, fontSize: 9, letterSpacing: "0.08em", color: TONE_COLOR[e.tone] ?? TEXT_SEC }}>{e.type}</span>
              <span style={{ fontFamily: FONT_MONO, fontSize: 9, color: TEXT_TER }}>{new Date(e.ts).toLocaleTimeString("de-DE")}</span>
            </div>
            <div style={{ marginTop: 3, fontSize: 12, color: "#E2E2E6" }}>{e.msg}</div>
          </div>)}
      </div>
    </div>;
}

export { LedgerApp };
