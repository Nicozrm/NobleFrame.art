import React, { useRef, useState } from "react";
import { GOLD, HAIRLINE, TEXT_TER, APP_PAD } from "../theme.js";

function SynthPadApp() {
  const audioRef = useRef(null);
  const [active, setActive] = useState(null);
  const SEMIS = [0, 3, 5, 7, 10, 12, 15, 17, 19, 22, 24, 27, 29, 31, 34, 36];
  const play = (i) => {
    const AC = window.AudioContext ?? window.webkitAudioContext;
    if (!AC) return;
    if (!audioRef.current) audioRef.current = new AC();
    const ac = audioRef.current;
    if (ac.state === "suspended") void ac.resume();
    const f = 220 * Math.pow(2, SEMIS[i] / 12);
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = "triangle";
    osc.frequency.value = f;
    gain.gain.setValueAtTime(1e-4, ac.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.22, ac.currentTime + 0.012);
    gain.gain.exponentialRampToValueAtTime(1e-4, ac.currentTime + 0.55);
    osc.connect(gain);
    gain.connect(ac.destination);
    osc.start();
    osc.stop(ac.currentTime + 0.6);
    setActive(i);
    setTimeout(() => setActive((cur) => cur === i ? null : cur), 220);
  };
  return <div style={{ ...APP_PAD, display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ fontSize: 11, color: TEXT_TER, fontStyle: "italic" }}>A-Moll-Pentatonik · 16 Pads · echte Web-Audio-Töne.</div>
      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gridTemplateRows: "repeat(4, 1fr)", gap: 9 }}>
        {SEMIS.map((_, i) => <button
    key={i}
    onPointerDown={() => play(i)}
    style={{ borderRadius: 12, border: `1px solid ${active === i ? "rgba(217,180,91,0.7)" : HAIRLINE}`, background: active === i ? "rgba(217,180,91,0.32)" : "linear-gradient(180deg, rgba(255,255,255,0.07), rgba(255,255,255,0.02))", color: active === i ? GOLD : TEXT_TER, fontSize: 11, fontVariantNumeric: "tabular-nums", transition: "background 100ms ease, border-color 100ms ease", touchAction: "manipulation" }}
  >
            {i + 1}
          </button>)}
      </div>
    </div>;
}

export { SynthPadApp };
