import React, { useRef, useState, useEffect } from "react";
import { GOLD, BLOOD, VERDIGRIS, HAIRLINE, HAIRLINE_SOFT, TEXT_PRI } from "../theme.js";
import { GoldButton } from "../components/GoldButton.jsx";

function PaintApp({ ctx }) {
  const canvasRef = useRef(null);
  const drawing = useRef(false);
  const [color, setColor] = useState(GOLD);
  const [brush, setBrush] = useState(6);
  const CANVAS_BG = "#141417";
  const W = 1080, H = 680;
  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const g = cv.getContext("2d");
    if (!g) return;
    g.fillStyle = CANVAS_BG;
    g.fillRect(0, 0, W, H);
  }, []);
  const pos = (e) => {
    const cv = canvasRef.current;
    const r = cv.getBoundingClientRect();
    return [(e.clientX - r.left) / r.width * W, (e.clientY - r.top) / r.height * H];
  };
  const start = (e) => {
    const g = canvasRef.current?.getContext("2d");
    if (!g) return;
    drawing.current = true;
    e.target.setPointerCapture(e.pointerId);
    const [x, y] = pos(e);
    g.beginPath();
    g.moveTo(x, y);
    g.strokeStyle = color;
    g.lineWidth = brush;
    g.lineCap = "round";
    g.lineJoin = "round";
  };
  const move = (e) => {
    if (!drawing.current) return;
    const g = canvasRef.current?.getContext("2d");
    if (!g) return;
    const [x, y] = pos(e);
    g.lineTo(x, y);
    g.stroke();
  };
  const end = () => {
    drawing.current = false;
  };
  const clear = () => {
    const g = canvasRef.current?.getContext("2d");
    if (!g) return;
    g.fillStyle = CANVAS_BG;
    g.fillRect(0, 0, W, H);
  };
  const save = () => {
    const cv = canvasRef.current;
    if (!cv) return;
    ctx.savePaintFile(cv.toDataURL("image/jpeg", 0.72));
  };
  const PALETTE = [GOLD, "#E8E4D8", BLOOD, VERDIGRIS, "#FFFFFF", CANVAS_BG];
  return <div style={{ display: "flex", flexDirection: "column", height: "100%", padding: 12, gap: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
        <div style={{ display: "flex", gap: 6 }}>
          {PALETTE.map((c) => <button key={c} onClick={() => setColor(c)} aria-label={`Farbe ${c}`} style={{ width: 22, height: 22, borderRadius: "50%", background: c, border: c === color ? `2px solid ${TEXT_PRI}` : `1px solid ${HAIRLINE}` }} />)}
        </div>
        <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
          {[3, 6, 12, 22].map((b) => <button key={b} onClick={() => setBrush(b)} aria-label={`Pinsel ${b}`} style={{ width: 26, height: 26, borderRadius: 7, display: "flex", alignItems: "center", justifyContent: "center", background: b === brush ? "rgba(217,180,91,0.18)" : "rgba(255,255,255,0.05)", border: `1px solid ${b === brush ? "rgba(217,180,91,0.45)" : HAIRLINE_SOFT}` }}>
              <span style={{ width: Math.min(b, 16), height: Math.min(b, 16), borderRadius: "50%", background: "#D8D8DC" }} />
            </button>)}
        </div>
        <div style={{ marginLeft: "auto", display: "flex", gap: 7 }}>
          <GoldButton small variant="ghost" label="Leeren" onClick={clear} />
          <GoldButton small label="In Files sichern" icon="⤓" onClick={save} />
        </div>
      </div>
      <canvas
    ref={canvasRef}
    width={W}
    height={H}
    onPointerDown={start}
    onPointerMove={move}
    onPointerUp={end}
    onPointerLeave={end}
    style={{ flex: 1, width: "100%", borderRadius: 10, border: `1px solid ${HAIRLINE_SOFT}`, background: CANVAS_BG, touchAction: "none", cursor: "crosshair" }}
  />
    </div>;
}

export { PaintApp };
