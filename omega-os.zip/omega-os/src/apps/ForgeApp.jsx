import React from "react";
import { HAIRLINE_SOFT, TEXT_TER, FONT_MONO, APP_PAD } from "../theme.js";
import { GoldButton } from "../components/GoldButton.jsx";

function ForgeApp({ ctx }) {
  return <div style={{ ...APP_PAD, display: "flex", flexDirection: "column", gap: 10 }}>
      <div style={{ fontSize: 11, color: TEXT_TER, fontStyle: "italic" }}>Schreibe in die Esse. Jeder Schlag kostet das Gefüge — und nährt das Werk.</div>
      <textarea
    value={ctx.forgeContent}
    onChange={(e) => ctx.setForgeContent(e.target.value)}
    spellCheck={false}
    style={{ flex: 1, resize: "none", padding: "10px 12px", borderRadius: 10, background: "rgba(0,0,0,0.35)", border: `1px solid ${HAIRLINE_SOFT}`, color: "#E8E4D8", fontFamily: FONT_MONO, fontSize: 12, lineHeight: 1.6, outline: "none" }}
  />
      <div><GoldButton label="Transmutieren · Coagula II" onClick={() => ctx.doAlchemy("create", 2)} /></div>
    </div>;
}

export { ForgeApp };
