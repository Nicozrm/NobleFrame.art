import React from "react";
import { GOLD, CARD_BG, HAIRLINE_SOFT, TEXT_SEC, TEXT_TER, FONT_DISPLAY, APP_PAD } from "../theme.js";

function WeatherApp() {
  const doy = Math.floor((Date.now() - new Date((/* @__PURE__ */ new Date()).getFullYear(), 0, 0).getTime()) / 864e5);
  const conds = [
    { glyph: "\u2600", label: "Klar" },
    { glyph: "\u26C5", label: "Heiter" },
    { glyph: "\u2601", label: "Bedeckt" },
    { glyph: "\u2602", label: "Regen" }
  ];
  const seed = (n) => conds[(doy + n * 3) % conds.length];
  const temp = (n) => 14 + (doy * 7 + n * 13) % 11;
  const days = ["Heute", "Fr", "Sa", "So", "Mo"];
  return <div style={{ ...APP_PAD, display: "flex", flexDirection: "column", gap: 14 }}>
      <div>
        <div style={{ fontSize: 12, color: TEXT_SEC }}>Steinfurt-Borghorst</div>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginTop: 6 }}>
          <span style={{ fontSize: 46, color: GOLD }}>{seed(0).glyph}</span>
          <div>
            <div style={{ fontFamily: FONT_DISPLAY, fontSize: 48, color: "#EFE7CF", lineHeight: 1 }}>{temp(0)}°</div>
            <div style={{ fontSize: 12, color: TEXT_SEC, marginTop: 2 }}>{seed(0).label} · gefühlt {temp(0) - 1}°</div>
          </div>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 8 }}>
        {days.map((d, i) => <div key={d} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 5, padding: "10px 4px", background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 10 }}>
            <span style={{ fontSize: 10.5, color: TEXT_SEC }}>{d}</span>
            <span style={{ fontSize: 18, color: GOLD }}>{seed(i).glyph}</span>
            <span style={{ fontSize: 12.5, color: "#E6E6EA", fontVariantNumeric: "tabular-nums" }}>{temp(i)}°</span>
          </div>)}
      </div>
      <div style={{ marginTop: "auto", fontSize: 10, color: TEXT_TER, fontStyle: "italic" }}>Feld-Simulation · kein Live-Feed. Das Wetter des Void ist beständig.</div>
    </div>;
}

export { WeatherApp };
