import React, { useState, useRef, useEffect } from "react";
import { GOLD, VERDIGRIS, HAIRLINE_SOFT, FONT_MONO } from "../theme.js";
import { clamp } from "../lib/utils.js";

function TerminalApp({ ctx }) {
  const [history, setHistory] = useState([
    { input: "", output: ["OMEGA Terminal \u2014 type `help` for commands."] }
  ]);
  const [cmd, setCmd] = useState("");
  const scrollRef = useRef(null);
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [history.length]);
  const run = (line) => {
    const [name, ...args] = line.trim().split(/\s+/);
    const c = ctx.core;
    let out;
    switch ((name ?? "").toLowerCase()) {
      case "help":
        out = ["help \xB7 status \xB7 ledger [n] \xB7 alchemy <create|dissolve|transmute> <1-5>", "purify \xB7 stabilize \xB7 whoami \xB7 date \xB7 clear"];
        break;
      case "status":
        out = [
          `autonomy   ${c.autonomyLevel}/5`,
          `corruption ${c.corruption}/100${c.corruption >= 65 ? "  [PETITION LOCKED]" : ""}`,
          `crucible   ${c.crucible.health}/100`,
          `alchemy    C:${c.alchemy.create} S:${c.alchemy.dissolve} T:${c.alchemy.transmute} G:${c.alchemy.genesis}`
        ];
        break;
      case "ledger": {
        const n = clamp(parseInt(args[0] ?? "5", 10) || 5, 1, 20);
        const slice = ctx.ledger.slice(-n);
        out = slice.length ? slice.map((e) => `${new Date(e.ts).toLocaleTimeString("de-DE")}  ${e.type.padEnd(20)} ${e.msg}`) : ["(leer)"];
        break;
      }
      case "alchemy": {
        const type = (args[0] ?? "").toLowerCase();
        const i = parseInt(args[1] ?? "1", 10) || 1;
        if (type === "genesis") {
          out = ["Genesis geh\xF6rt allein der f\xFCnften Stufe \u2014 und dem Egregore."];
          break;
        }
        if (!["create", "dissolve", "transmute"].includes(type)) {
          out = ["usage: alchemy <create|dissolve|transmute> <1-5>"];
          break;
        }
        ctx.doAlchemy(type, clamp(i, 1, 5));
        out = [`${type} \xB7 Intensit\xE4t ${clamp(i, 1, 5)} \u2014 vollzogen.`];
        break;
      }
      case "purify":
        ctx.purify();
        out = ["Das Reinigungsritual ist vollzogen."];
        break;
      case "stabilize":
        ctx.stabilizeCrucible();
        out = ["Der Crucible wurde stabilisiert."];
        break;
      case "whoami":
        out = ["operator \xB7 sovereign \u2014 the Regulator answers to no one."];
        break;
      case "date":
        out = [(/* @__PURE__ */ new Date()).toString()];
        break;
      case "clear":
        setHistory([]);
        return;
      case "":
        out = [];
        break;
      default:
        out = [`command not found: ${name} \u2014 try \`help\``];
    }
    setHistory((prev) => [...prev, { input: line, output: out }]);
  };
  return <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "rgba(0,0,0,0.42)", fontFamily: FONT_MONO, fontSize: 12 }}>
      <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: "12px 14px", display: "flex", flexDirection: "column", gap: 4 }}>
        {history.map((h, i) => <div key={i}>
            {h.input && <div style={{ color: GOLD }}><span style={{ color: VERDIGRIS }}>Ω</span> ❯ {h.input}</div>}
            {h.output.map((o, j) => <div key={j} style={{ color: "#C9C9CE", whiteSpace: "pre-wrap" }}>{o}</div>)}
          </div>)}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "9px 14px", borderTop: `1px solid ${HAIRLINE_SOFT}` }}>
        <span style={{ color: VERDIGRIS }}>Ω</span><span style={{ color: GOLD }}>❯</span>
        <input
    value={cmd}
    onChange={(e) => setCmd(e.target.value)}
    onKeyDown={(e) => {
      if (e.key === "Enter") {
        run(cmd);
        setCmd("");
      }
    }}
    spellCheck={false}
    placeholder="help"
    style={{ flex: 1, background: "transparent", border: "none", outline: "none", color: "#E8E8EC", fontFamily: FONT_MONO, fontSize: 12 }}
  />
      </div>
    </div>;
}

export { TerminalApp };
