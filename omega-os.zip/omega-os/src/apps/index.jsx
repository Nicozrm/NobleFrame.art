import React from "react";
import { AppStoreApp } from "./AppStoreApp.jsx";
import { EgregoreApp } from "./EgregoreApp.jsx";
import { CrucibleApp } from "./CrucibleApp.jsx";
import { ForgeApp } from "./ForgeApp.jsx";
import { LedgerApp } from "./LedgerApp.jsx";
import { AlchemyApp } from "./AlchemyApp.jsx";
import { RegulatorApp } from "./RegulatorApp.jsx";
import { FilesApp } from "./FilesApp.jsx";
import { TerminalApp } from "./TerminalApp.jsx";
import { BrowserApp } from "./BrowserApp.jsx";
import { AboutApp } from "./AboutApp.jsx";
import { WeatherApp } from "./WeatherApp.jsx";
import { WorldClockApp } from "./WorldClockApp.jsx";
import { DiceApp } from "./DiceApp.jsx";
import { Game2048App } from "./Game2048App.jsx";
import { PaintApp } from "./PaintApp.jsx";
import { SynthPadApp } from "./SynthPadApp.jsx";

function renderApp(app, ctx) {
  switch (app) {
    case "AppStore":
      return <AppStoreApp ctx={ctx} />;
    case "Egregore":
      return <EgregoreApp ctx={ctx} />;
    case "Crucible":
      return <CrucibleApp ctx={ctx} />;
    case "Forge":
      return <ForgeApp ctx={ctx} />;
    case "Ledger":
      return <LedgerApp ctx={ctx} />;
    case "Alchemy":
      return <AlchemyApp ctx={ctx} />;
    case "Regulator":
      return <RegulatorApp ctx={ctx} />;
    case "Files":
      return <FilesApp ctx={ctx} />;
    case "Terminal":
      return <TerminalApp ctx={ctx} />;
    case "Browser":
      return <BrowserApp ctx={ctx} />;
    case "About":
      return <AboutApp />;
    case "Weather":
      return <WeatherApp />;
    case "WorldClock":
      return <WorldClockApp now={ctx.now} />;
    case "Dice":
      return <DiceApp ctx={ctx} />;
    case "Game2048":
      return <Game2048App ctx={ctx} />;
    case "Paint":
      return <PaintApp ctx={ctx} />;
    case "SynthPad":
      return <SynthPadApp />;
    default:
      return null;
  }
}

export { renderApp };
