import React, { useState } from "react";
import { GOLD, HAIRLINE, TEXT_SEC, TEXT_TER, FONT_DISPLAY, APP_PAD } from "../theme.js";
import { sleep } from "../lib/utils.js";
import { GoldButton } from "../components/GoldButton.jsx";

function DiceApp({ ctx }) {
  const FACES = ["\u2680", "\u2681", "\u2682", "\u2683", "\u2684", "\u2685"];
  const [dice, setDice] = useState([4, 2]);
  const [rolling, setRolling] = useState(false);
  const roll = async () => {
    if (rolling) return;
    setRolling(true);
    for (let i = 0; i < 9; i++) {
      setDice([Math.floor(Math.random() * 6), Math.floor(Math.random() * 6)]);
      await sleep(62 + i * 14);
    }
    const final = [Math.floor(Math.random() * 6), Math.floor(Math.random() * 6)];
    setDice(final);
    setRolling(false);
    ctx.doAlchemy("transmute", 1);
  };
  return <div style={{ ...APP_PAD, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 20 }}>
      <div style={{ display: "flex", gap: 18 }}>
        {dice.map((d, i) => <div key={i} style={{ width: 86, height: 86, borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 64, color: GOLD, background: "linear-gradient(180deg, rgba(255,255,255,0.09), rgba(255,255,255,0.02))", border: `1px solid ${HAIRLINE}`, boxShadow: "0 12px 30px rgba(0,0,0,0.45)" }}>
            {FACES[d]}
          </div>)}
      </div>
      <div style={{ fontFamily: FONT_DISPLAY, fontSize: 18, color: TEXT_SEC, fontStyle: "italic" }}>Summe · {dice[0] + dice[1] + 2}</div>
      <GoldButton label={rolling ? "Die W\xFCrfel fallen\u2026" : "W\xFCrfeln"} onClick={() => void roll()} disabled={rolling} />
      <div style={{ fontSize: 10, color: TEXT_TER, fontStyle: "italic" }}>Jeder Wurf ist eine kleine Transmutation.</div>
    </div>;
}

export { DiceApp };
