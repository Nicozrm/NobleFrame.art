import React, { useState } from "react";
import { GOLD, GOLD_SOFT, BLOOD, CARD_BG, HAIRLINE_SOFT, TEXT_SEC, FONT_DISPLAY, APP_PAD } from "../theme.js";
import { GoldButton } from "../components/GoldButton.jsx";

function RegulatorApp({ ctx }) {
  const [deliberating, setDeliberating] = useState(false);
  const [verdict, setVerdict] = useState(null);
  const lvl = ctx.core.autonomyLevel;
  const corr = ctx.core.corruption;
  const petition = async () => {
    if (deliberating) return;
    setDeliberating(true);
    setVerdict(null);
    const res = await ctx.petitionRaise();
    setVerdict(res);
    setDeliberating(false);
  };
  return <div style={{ ...APP_PAD, display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 4 }}>
        <div style={{ fontFamily: FONT_DISPLAY, fontSize: 60, color: GOLD, lineHeight: 1 }}>{lvl}</div>
        <div style={{ fontSize: 9.5, letterSpacing: "0.26em", color: TEXT_SEC, fontWeight: 700, marginTop: 2 }}>AUTONOMIE-STUFE</div>
        <div style={{ display: "flex", gap: 5, marginTop: 10 }}>
          {[1, 2, 3, 4, 5].map((i) => <div key={i} style={{ width: 18, height: 4.5, borderRadius: 2, background: i <= lvl ? GOLD : "rgba(255,255,255,0.1)", transition: "background 300ms" }} />)}
        </div>
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <div style={{ flex: 1 }}><GoldButton label={deliberating ? "Der Regulator erw\xE4gt\u2026" : "Petition: Erheben"} onClick={() => void petition()} disabled={deliberating || lvl >= 5} /></div>
        <div style={{ flex: 1, textAlign: "right" }}><GoldButton label="Senken (frei)" variant="ghost" onClick={ctx.lowerAutonomy} disabled={lvl <= 0} /></div>
      </div>
      {verdict && <div style={{ padding: "8px 12px", borderRadius: 10, border: `1px solid ${verdict.granted ? "rgba(217,180,91,0.4)" : "rgba(194,91,82,0.45)"}`, fontFamily: FONT_DISPLAY, fontStyle: "italic", fontSize: 13.5, color: verdict.granted ? GOLD : BLOOD }}>
          {verdict.text}
        </div>}
      <div>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
          <span style={{ fontSize: 10, letterSpacing: "0.22em", color: TEXT_SEC, fontWeight: 700 }}>KORRUPTION</span>
          <span style={{ fontFamily: FONT_DISPLAY, fontSize: 24, color: corr >= 65 ? BLOOD : "#E6E0CE" }}>{corr}</span>
        </div>
        <div style={{ marginTop: 5, height: 5, borderRadius: 3, background: "rgba(255,255,255,0.08)" }}>
          <div style={{ width: `${corr}%`, height: "100%", borderRadius: 3, background: corr >= 65 ? BLOOD : GOLD_SOFT, transition: "width 400ms, background 400ms" }} />
        </div>
        <div style={{ marginTop: 9 }}><GoldButton label="Reinigungsritual (−30)" variant="verdigris" onClick={ctx.purify} /></div>
      </div>
      <div style={{ marginTop: "auto", padding: "10px 12px", background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 10 }}>
        <div style={{ fontFamily: FONT_DISPLAY, fontStyle: "italic", fontSize: 12.5, color: TEXT_SEC, lineHeight: 1.5 }}>
          Senken ist frei. Erheben verlangt Petition. Bei Korruption ≥ 65 wird jede Erhöhung verweigert.
          <span style={{ color: GOLD_SOFT }}> Die Asymmetrie ist das Gesetz.</span>
        </div>
      </div>
    </div>;
}

export { RegulatorApp };
