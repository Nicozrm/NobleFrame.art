import React, { useState, useRef, useCallback, useEffect } from "react";
import { GOLD, INK_ON_GOLD, HAIRLINE_SOFT, TEXT_SEC, TEXT_TER, FONT_DISPLAY, APP_PAD } from "../theme.js";
import { GoldButton } from "../components/GoldButton.jsx";

function slideRow(row) {
  const vals = row.filter((v) => v !== 0);
  const out = [];
  let gained = 0;
  for (let i = 0; i < vals.length; i++) {
    if (i + 1 < vals.length && vals[i] === vals[i + 1]) {
      out.push(vals[i] * 2);
      gained += vals[i] * 2;
      i++;
    } else out.push(vals[i]);
  }
  while (out.length < 4) out.push(0);
  return { row: out, gained };
}
function moveBoard(board, dir) {
  const next = [...board];
  let gained = 0;
  const idx = (r, c) => r * 4 + c;
  for (let line = 0; line < 4; line++) {
    const cells = dir === "left" || dir === "right" ? [0, 1, 2, 3].map((c) => next[idx(line, c)]) : [0, 1, 2, 3].map((r) => next[idx(r, line)]);
    const ordered = dir === "right" || dir === "down" ? [...cells].reverse() : cells;
    const { row, gained: g } = slideRow(ordered);
    gained += g;
    const restored = dir === "right" || dir === "down" ? [...row].reverse() : row;
    restored.forEach((v, i) => {
      if (dir === "left" || dir === "right") next[idx(line, i)] = v;
      else next[idx(i, line)] = v;
    });
  }
  const moved = next.some((v, i) => v !== board[i]);
  return { board: next, gained, moved };
}
function addRandomTile(board) {
  const empty = board.map((v, i) => v === 0 ? i : -1).filter((i) => i >= 0);
  if (empty.length === 0) return board;
  const next = [...board];
  next[empty[Math.floor(Math.random() * empty.length)]] = Math.random() < 0.9 ? 2 : 4;
  return next;
}
function isGameOver(board) {
  if (board.includes(0)) return false;
  for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) {
    const v = board[r * 4 + c];
    if (c < 3 && board[r * 4 + c + 1] === v) return false;
    if (r < 3 && board[(r + 1) * 4 + c] === v) return false;
  }
  return true;
}
function freshBoard() {
  return addRandomTile(addRandomTile(Array(16).fill(0)));
}
function Game2048App({ ctx }) {
  const [board, setBoard] = useState(() => freshBoard());
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);
  const milestoneRef = useRef(64);
  const active = ctx.focusedApp === "Game2048";
  const doMove = useCallback((dir) => {
    if (over) return;
    setBoard((prev) => {
      const { board: movedBoard, gained, moved } = moveBoard(prev, dir);
      if (!moved) return prev;
      const withTile = addRandomTile(movedBoard);
      setScore((s) => s + gained);
      const maxTile = Math.max(...withTile);
      if (maxTile >= 128 && maxTile > milestoneRef.current) {
        milestoneRef.current = maxTile;
        ctx.doAlchemy("create", 1);
      }
      if (isGameOver(withTile)) setOver(true);
      return withTile;
    });
  }, [over, ctx]);
  useEffect(() => {
    if (!active) return;
    const onKey = (e) => {
      const map = { ArrowLeft: "left", ArrowRight: "right", ArrowUp: "up", ArrowDown: "down" };
      const dir = map[e.key];
      if (dir) {
        e.preventDefault();
        doMove(dir);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active, doMove]);
  const newGame = () => {
    setBoard(freshBoard());
    setScore(0);
    setOver(false);
    milestoneRef.current = 64;
  };
  const tileStyle = (v) => {
    if (v === 0) return { background: "rgba(255,255,255,0.045)", color: "transparent" };
    const a = Math.min(0.12 + Math.log2(v) * 0.075, 0.95);
    return { background: `rgba(217,180,91,${a})`, color: v >= 64 ? INK_ON_GOLD : "#F0E9D6", fontWeight: 700 };
  };
  return <div style={{ ...APP_PAD, display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 10, letterSpacing: "0.2em", color: TEXT_SEC, fontWeight: 700 }}>SCORE</div>
          <div style={{ fontFamily: FONT_DISPLAY, fontSize: 28, color: GOLD, lineHeight: 1 }}>{score}</div>
        </div>
        <GoldButton small label="Neues Spiel" variant="ghost" onClick={newGame} />
      </div>
      <div style={{ position: "relative", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8, padding: 8, background: "rgba(0,0,0,0.3)", borderRadius: 12, border: `1px solid ${HAIRLINE_SOFT}` }}>
        {board.map((v, i) => <div key={i} style={{ aspectRatio: "1", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: v >= 1024 ? 17 : v >= 128 ? 20 : 23, transition: "background 140ms ease", ...tileStyle(v) }}>
            {v || "\xB7"}
          </div>)}
        {over && <div style={{ position: "absolute", inset: 0, borderRadius: 12, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10, background: "rgba(8,8,10,0.82)", backdropFilter: "blur(4px)" }}>
            <div style={{ fontFamily: FONT_DISPLAY, fontStyle: "italic", fontSize: 19, color: "#EDE6D2" }}>Das Feld ist erschöpft.</div>
            <GoldButton small label="Erneut wirken" onClick={newGame} />
          </div>}
      </div>
      <div style={{ display: "flex", justifyContent: "center", gap: 7 }}>
        {["left", "up", "down", "right"].map((d) => <GoldButton key={d} small variant="ghost" label={{ left: "\u2190", up: "\u2191", down: "\u2193", right: "\u2192" }[d]} onClick={() => doMove(d)} />)}
      </div>
      <div style={{ fontSize: 10, color: TEXT_TER, fontStyle: "italic", textAlign: "center" }}>Pfeiltasten oder Buttons · Kachel ≥ 128 nährt Coagula.</div>
    </div>;
}

export { Game2048App };
