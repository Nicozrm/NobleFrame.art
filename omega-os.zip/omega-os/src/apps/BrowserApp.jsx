import React from "react";
import { GOLD, CARD_BG, HAIRLINE_SOFT, TEXT_SEC, TEXT_TER, FONT_DISPLAY } from "../theme.js";

function BrowserApp({ ctx }) {
  const tiles = [
    { label: "Charta lesen", desc: "Die sechs Regeln des Crucible.", app: "Crucible" },
    { label: "Ledger \xF6ffnen", desc: "Die ewige Chronik aller Akte.", app: "Ledger" },
    { label: "App Store", desc: "Kuratiert f\xFCr OMEGA.", app: "AppStore" }
  ];
  return <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "9px 12px", borderBottom: `1px solid ${HAIRLINE_SOFT}` }}>
        <span style={{ color: TEXT_TER, fontSize: 12 }}>⟨</span><span style={{ color: TEXT_TER, fontSize: 12 }}>⟩</span>
        <div style={{ flex: 1, padding: "5px 12px", borderRadius: 999, background: "rgba(255,255,255,0.06)", border: `1px solid ${HAIRLINE_SOFT}`, fontSize: 11.5, color: TEXT_SEC, textAlign: "center" }}>
          omega://net — das Netz des Void ist nach innen gerichtet
        </div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: 18, display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
        <div style={{ fontFamily: FONT_DISPLAY, fontSize: 34, color: "#EFE7CF", marginTop: 8 }}>OMEGA <span style={{ color: GOLD }}>NET</span></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, width: "100%", maxWidth: 470 }}>
          {tiles.map((t) => <div key={t.label} onClick={() => ctx.openApp(t.app)} style={{ padding: "13px 12px", background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 11, cursor: "pointer" }}>
              <div style={{ fontSize: 12.5, fontWeight: 600, color: GOLD }}>{t.label}</div>
              <div style={{ marginTop: 4, fontSize: 10.5, color: TEXT_SEC, lineHeight: 1.4 }}>{t.desc}</div>
            </div>)}
        </div>
        <div style={{ fontSize: 10, color: TEXT_TER, fontStyle: "italic" }}>Externe Adressen verlassen das Feld — und das Feld verlässt man nicht.</div>
      </div>
    </div>;
}

export { BrowserApp };
