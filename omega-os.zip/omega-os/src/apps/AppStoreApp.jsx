import React, { useState } from "react";
import { GOLD, GOLD_SOFT, CARD_BG, CARD_BG_HOVER, HAIRLINE_SOFT, TEXT_PRI, TEXT_SEC, TEXT_TER, FONT_DISPLAY, FONT_SYS, APP_PAD } from "../theme.js";
import { STORE_APPS } from "../data/apps.js";
import { GoldButton } from "../components/GoldButton.jsx";

function AppStoreApp({ ctx }) {
  const [query, setQuery] = useState("");
  const q = query.trim().toLowerCase();
  const apps = STORE_APPS.filter((a) => !q || a.title.toLowerCase().includes(q) || a.category.toLowerCase().includes(q) || a.desc.toLowerCase().includes(q));
  return <div style={{ ...APP_PAD, padding: "16px 18px" }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, marginBottom: 16 }}>
        <div>
          <div style={{ fontFamily: FONT_DISPLAY, fontSize: 30, color: "#EFE7CF", lineHeight: 1.05 }}>App Store</div>
          <div style={{ marginTop: 4, fontSize: 11.5, color: GOLD_SOFT, letterSpacing: "0.04em" }}>Curated for OMEGA · install &amp; add to your dock</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "6px 12px", borderRadius: 999, background: "rgba(255,255,255,0.06)", border: `1px solid ${HAIRLINE_SOFT}`, minWidth: 180 }}>
          <span style={{ color: TEXT_TER, fontSize: 12 }}>⌕</span>
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search apps…" style={{ background: "transparent", border: "none", outline: "none", color: TEXT_PRI, fontSize: 12.5, width: "100%", fontFamily: FONT_SYS }} />
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {apps.map((a) => {
    const installed = ctx.core.installedApps.includes(a.id);
    return <div
      key={a.id}
      style={{ background: CARD_BG, border: `1px solid ${HAIRLINE_SOFT}`, borderRadius: 13, padding: "13px 14px", display: "flex", flexDirection: "column", gap: 8, transition: "background 160ms ease" }}
      onMouseEnter={(e) => e.currentTarget.style.background = CARD_BG_HOVER}
      onMouseLeave={(e) => e.currentTarget.style.background = CARD_BG}
    >
              <div style={{ display: "flex", alignItems: "flex-start", gap: 11 }}>
                <div style={{ width: 42, height: 42, borderRadius: 10, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, color: GOLD, background: "rgba(217,180,91,0.10)", border: "1px solid rgba(217,180,91,0.22)" }}>{a.glyph}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 600, color: TEXT_PRI }}>{a.title}</div>
                  <div style={{ fontSize: 9.5, letterSpacing: "0.18em", color: GOLD_SOFT, fontWeight: 700, marginTop: 1 }}>{a.category}</div>
                </div>
                <GoldButton small icon={installed ? void 0 : "\u2913"} label={installed ? "Open" : "Get"} variant={installed ? "ghost" : "gold"} onClick={() => {
      if (!installed) ctx.installApp(a.id);
      ctx.openApp(a.id);
    }} />
              </div>
              <div style={{ fontSize: 11.5, color: TEXT_SEC, lineHeight: 1.45 }}>{a.desc}</div>
            </div>;
  })}
        {apps.length === 0 && <div style={{ gridColumn: "1 / -1", color: TEXT_TER, fontSize: 12.5, fontStyle: "italic" }}>Nichts im Katalog trägt diesen Namen.</div>}
      </div>
    </div>;
}

export { AppStoreApp };
