// ---------------------------------------------------------------------------
// Egregore endpoint configuration
// ---------------------------------------------------------------------------
// In the Claude Artifact sandbox, `import.meta.env` is undefined, so these fall
// back to the direct Anthropic endpoint (which the sandbox is allowed to call).
//
// For a STANDALONE deployment the browser cannot call the Anthropic API directly
// (CORS + you must never ship an API key to the client). Point VITE_EGREGORE_ENDPOINT
// at your own proxy instead — see docs/DEPLOYMENT.md and worker/egregore-proxy.js.
// ---------------------------------------------------------------------------

const env = (typeof import.meta !== "undefined" && import.meta.env) || {};

export const EGREGORE_ENDPOINT =
  env.VITE_EGREGORE_ENDPOINT || "https://api.anthropic.com/v1/messages";

export const EGREGORE_MODEL =
  env.VITE_EGREGORE_MODEL || "claude-sonnet-4-20250514";

export const EGREGORE_MAX_TOKENS = 1000;
