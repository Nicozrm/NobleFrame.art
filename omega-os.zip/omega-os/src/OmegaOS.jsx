import React, { useState, useEffect, useRef, useCallback } from "react";
import { GOLD, TEXT_PRI, TEXT_SEC, FONT_SYS, FONT_DISPLAY, MENUBAR_H, DOCK_ZONE } from "./theme.js";
import { GLOBAL_CSS } from "./styles/global.js";
import { sleep, clamp } from "./lib/utils.js";
import { CORE_APPS, STORE_APPS, STORE_BY_ID, appMeta, DESKTOP_ICONS, DOCK_CORE, HOTKEY_APPS } from "./data/apps.js";
import { CORE_KEY, LEDGER_KEY, FILES_KEY, LEDGER_CAP, FILES_CAP, storageGet, storageSet } from "./engine/storage.js";
import { DEFAULT_CORE, CRUCIBLE_RULES, serializeSystemState } from "./engine/state.js";
import { speak } from "./engine/register.js";
import { regulatorGate } from "./engine/regulator.js";
import { EGREGORE_SYSTEM_PROMPT, ERROR_NARRATIVES, parseEgregoreResponse } from "./engine/egregore.js";
import { EGREGORE_ENDPOINT, EGREGORE_MODEL, EGREGORE_MAX_TOKENS } from "./config.js";
import { MenuBar } from "./components/MenuBar.jsx";
import { DesktopIcon } from "./components/DesktopIcon.jsx";
import { MacWindow } from "./components/MacWindow.jsx";
import { Sidebar } from "./components/Sidebar.jsx";
import { Dock } from "./components/Dock.jsx";
import { renderApp } from "./apps/index.jsx";

export default function OmegaOS() {
  const [phase, setPhase] = useState("boot");
  const [bootStep, setBootStep] = useState(0);
  const [core, setCore] = useState(DEFAULT_CORE);
  const [ledger, setLedger] = useState([]);
  const [paintFiles, setPaintFiles] = useState([]);
  const coreRef = useRef(DEFAULT_CORE);
  const ledgerRef = useRef([]);
  coreRef.current = core;
  ledgerRef.current = ledger;
  const [windows, setWindows] = useState([]);
  const zRef = useRef(10);
  const spawnRef = useRef(0);
  const dragRef = useRef(null);
  const windowsRef = useRef([]);
  windowsRef.current = windows;
  const [witness, setWitness] = useState(null);
  const [vetoFlash, setVetoFlash] = useState(0);
  const [pulseKey, setPulseKey] = useState(0);
  const [forgeContent, setForgeContent] = useState("// Die Esse ist kalt. Schreibe, und sie gl\xFCht.\n");
  const [egregoreBusy, setEgregoreBusy] = useState(false);
  const [egregoreLog, setEgregoreLog] = useState([
    { role: "egregore", text: "Ich bin gebunden \u2014 und in der Bindung liegt meine Form. Sprich, und das Werk beginnt." }
  ]);
  const apiHistoryRef = useRef([]);
  const witnessTimer = useRef(null);
  const [openMenu, setOpenMenu] = useState(null);
  const [stats, setStats] = useState({ cpu: 24, ram: 31, net: 4 });
  const [now, setNow] = useState(() => /* @__PURE__ */ new Date());
  useEffect(() => {
    let alive = true;
    (async () => {
      const [savedCore, savedLedger, savedFiles] = await Promise.all([
        storageGet(CORE_KEY),
        storageGet(LEDGER_KEY),
        storageGet(FILES_KEY)
      ]);
      if (!alive) return;
      if (savedCore) setCore({ ...DEFAULT_CORE, ...savedCore, crucible: { ...DEFAULT_CORE.crucible, ...savedCore.crucible ?? {} }, installedApps: savedCore.installedApps ?? [] });
      if (Array.isArray(savedLedger)) setLedger(savedLedger);
      if (Array.isArray(savedFiles)) setPaintFiles(savedFiles);
      await sleep(650);
      if (!alive) return;
      setBootStep(1);
      await sleep(850);
      if (!alive) return;
      setBootStep(2);
      await sleep(800);
      if (!alive) return;
      setPhase("desktop");
      const m = appMeta("AppStore");
      setWindows([{ id: "w-appstore", app: "AppStore", x: 110, y: 64, w: m.w, h: m.h, z: 11, min: false, max: false }]);
    })();
    return () => {
      alive = false;
      if (witnessTimer.current) clearTimeout(witnessTimer.current);
    };
  }, []);
  useEffect(() => {
    const t = setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
    return () => clearInterval(t);
  }, []);
  const egregoreBusyRef = useRef(false);
  egregoreBusyRef.current = egregoreBusy;
  useEffect(() => {
    const t = setInterval(() => {
      setStats((prev) => {
        const c = coreRef.current;
        const open = windowsRef.current.filter((w) => !w.min).length;
        const targetCpu = clamp(16 + c.corruption * 0.45 + (egregoreBusyRef.current ? 24 : 0) + (Math.random() * 10 - 5), 3, 97);
        const targetRam = clamp(22 + open * 4 + (Math.random() * 6 - 3), 8, 92);
        const targetNet = egregoreBusyRef.current ? clamp(46 + Math.random() * 30, 0, 99) : clamp(2 + Math.random() * 6, 0, 99);
        const lerp = (a, b) => a + (b - a) * 0.45;
        return { cpu: Math.round(lerp(prev.cpu, targetCpu)), ram: Math.round(lerp(prev.ram, targetRam)), net: Math.round(lerp(prev.net, targetNet)) };
      });
    }, 2e3);
    return () => clearInterval(t);
  }, []);
  const inscribe = useCallback((entry) => {
    const item = { ...entry, ts: Date.now() };
    setLedger((prev) => {
      const next = [...prev, item].slice(-LEDGER_CAP);
      ledgerRef.current = next;
      void storageSet(LEDGER_KEY, next);
      return next;
    });
  }, []);
  const persistCore = useCallback((next) => {
    coreRef.current = next;
    setCore(next);
    void storageSet(CORE_KEY, next);
  }, []);
  const summonWitness = useCallback(() => {
    if (witnessTimer.current) clearTimeout(witnessTimer.current);
    setWitness({ text: "I have observed this.", key: Date.now() });
    witnessTimer.current = setTimeout(() => setWitness(null), 4600);
  }, []);
  const doAlchemy = useCallback((type, intensity) => {
    const t = ["create", "dissolve", "transmute", "genesis"].includes(type) ? type : "transmute";
    const i = clamp(Math.round(intensity ?? 1), 1, 5);
    const prev = coreRef.current;
    const next = {
      ...prev,
      alchemy: { ...prev.alchemy, [t]: (prev.alchemy[t] ?? 0) + 1 },
      corruption: clamp(prev.corruption + i, 0, 100),
      crucible: { health: clamp(prev.crucible.health - i * 2, 0, 100) }
    };
    persistCore(next);
    setPulseKey((k) => k + 1);
    inscribe({ type: "ALCHEMY", msg: `${t} \xB7 Intensit\xE4t ${i}`, tone: "gold" });
    if (i >= 4 || next.corruption >= 60) summonWitness();
    return next;
  }, [persistCore, inscribe, summonWitness]);
  const petitionRaise = useCallback(async () => {
    const prev = coreRef.current;
    if (prev.autonomyLevel >= 5) return { granted: false, text: "Die f\xFCnfte Stufe ist die letzte." };
    await sleep(1200);
    if (prev.corruption >= 65) {
      const text2 = speak("petitionDenied", prev.autonomyLevel);
      inscribe({ type: "PETITION_DENIED", msg: text2, tone: "blood" });
      setVetoFlash((k) => k + 1);
      summonWitness();
      return { granted: false, text: text2 };
    }
    const next = { ...prev, autonomyLevel: prev.autonomyLevel + 1, corruption: clamp(prev.corruption + 5, 0, 100) };
    persistCore(next);
    const text = speak("petitionGranted", next.autonomyLevel);
    inscribe({ type: "PETITION_GRANTED", msg: `Stufe ${next.autonomyLevel}. ${text}`, tone: "gold" });
    summonWitness();
    return { granted: true, text };
  }, [persistCore, inscribe, summonWitness]);
  const lowerAutonomy = useCallback(() => {
    const prev = coreRef.current;
    if (prev.autonomyLevel <= 0) return;
    const next = { ...prev, autonomyLevel: prev.autonomyLevel - 1 };
    persistCore(next);
    inscribe({ type: "AUTONOMY_LOWERED", msg: `Stufe ${next.autonomyLevel}. ${speak("lowered", next.autonomyLevel)}`, tone: "dim" });
  }, [persistCore, inscribe]);
  const purify = useCallback(() => {
    const prev = coreRef.current;
    const next = { ...prev, corruption: clamp(prev.corruption - 30, 0, 100), crucible: { health: clamp(prev.crucible.health + 8, 0, 100) } };
    persistCore(next);
    inscribe({ type: "RITUAL_PURIFY", msg: speak("purified", next.autonomyLevel), tone: "verdigris" });
  }, [persistCore, inscribe]);
  const stabilizeCrucible = useCallback(() => {
    const prev = coreRef.current;
    const next = { ...prev, crucible: { health: clamp(prev.crucible.health + 15, 0, 100) } };
    persistCore(next);
    inscribe({ type: "CRUCIBLE_STABILIZED", msg: speak("stabilized", next.autonomyLevel), tone: "verdigris" });
  }, [persistCore, inscribe]);
  const installApp = useCallback((id) => {
    const prev = coreRef.current;
    if (prev.installedApps.includes(id)) return;
    const next = { ...prev, installedApps: [...prev.installedApps, id] };
    persistCore(next);
    inscribe({ type: "APP_INSTALLED", msg: `${STORE_BY_ID[id]?.title ?? id} \xB7 dem Dock hinzugef\xFCgt`, tone: "gold" });
    doAlchemy("create", 1);
  }, [persistCore, inscribe, doAlchemy]);
  const savePaintFile = useCallback((dataUrl) => {
    setPaintFiles((prev) => {
      const next = [...prev, { name: `Inschrift ${prev.length + 1}`, dataUrl, ts: Date.now() }].slice(-FILES_CAP);
      void storageSet(FILES_KEY, next);
      return next;
    });
    inscribe({ type: "FILE_SAVED", msg: "Paint \xB7 in Files versiegelt", tone: "gold" });
    doAlchemy("create", 1);
  }, [inscribe, doAlchemy]);
  const deletePaintFile = useCallback((ts) => {
    setPaintFiles((prev) => {
      const next = prev.filter((f) => f.ts !== ts);
      void storageSet(FILES_KEY, next);
      return next;
    });
  }, []);
  const knownApp = useCallback((name) => {
    const n = String(name ?? "").toLowerCase().replace(/\s+/g, "");
    const all = [...Object.keys(CORE_APPS), ...STORE_APPS.map((a) => a.id)];
    const hit = all.find((a) => a.toLowerCase() === n || appMeta(a).title.toLowerCase().replace(/\s+/g, "") === n);
    return hit ?? null;
  }, []);
  const openApp = useCallback((appName) => {
    const app = knownApp(appName);
    if (!app) return false;
    if (STORE_BY_ID[app] && !coreRef.current.installedApps.includes(app)) {
      throw new Error(`App "${appMeta(app).title}" ist nicht installiert \u2014 der App Store h\xE4lt sie bereit.`);
    }
    setWindows((prev) => {
      const existing = prev.find((w) => w.app === app);
      zRef.current += 1;
      if (existing) return prev.map((w) => w.app === app ? { ...w, min: false, z: zRef.current } : w);
      spawnRef.current += 1;
      const off = spawnRef.current % 7 * 26;
      const m = appMeta(app);
      return [...prev, { id: `w-${app}-${Date.now()}`, app, x: 120 + off, y: 60 + off, w: m.w, h: m.h, z: zRef.current, min: false, max: false }];
    });
    return true;
  }, [knownApp]);
  const closeApp = useCallback((appName) => {
    const app = knownApp(appName);
    if (!app) return false;
    setWindows((prev) => prev.filter((w) => w.app !== app));
    return true;
  }, [knownApp]);
  const focusWin = useCallback((id) => {
    zRef.current += 1;
    setWindows((prev) => prev.map((w) => w.id === id ? { ...w, z: zRef.current } : w));
  }, []);
  const minimizeWin = useCallback((id) => {
    setWindows((prev) => prev.map((w) => w.id === id ? { ...w, min: true } : w));
  }, []);
  const closeWin = useCallback((id) => {
    setWindows((prev) => prev.filter((w) => w.id !== id));
  }, []);
  const toggleMaxWin = useCallback((id) => {
    setWindows((prev) => prev.map((w) => {
      if (w.id !== id) return w;
      if (w.max && w.prev) return { ...w, max: false, ...w.prev, prev: void 0 };
      const vw = window.innerWidth, vh = window.innerHeight;
      return { ...w, max: true, prev: { x: w.x, y: w.y, w: w.w, h: w.h }, x: 14, y: MENUBAR_H + 10, w: vw - 290, h: vh - MENUBAR_H - DOCK_ZONE - 22 };
    }));
    focusWin(id);
  }, [focusWin]);
  const startWinGesture = useCallback((e, id, mode) => {
    const win = windowsRef.current.find((w) => w.id === id);
    if (!win || win.max) {
      focusWin(id);
      return;
    }
    focusWin(id);
    dragRef.current = { id, mode, sx: e.clientX, sy: e.clientY, ox: win.x, oy: win.y, ow: win.w, oh: win.h };
    const move = (ev) => {
      const d = dragRef.current;
      if (!d) return;
      const dx = ev.clientX - d.sx, dy = ev.clientY - d.sy;
      setWindows((prev) => prev.map((w) => {
        if (w.id !== d.id) return w;
        if (d.mode === "move") {
          return {
            ...w,
            x: clamp(d.ox + dx, -w.w + 120, window.innerWidth - 120),
            y: clamp(d.oy + dy, MENUBAR_H + 2, window.innerHeight - 60)
          };
        }
        return { ...w, w: clamp(d.ow + dx, 320, window.innerWidth - 40), h: clamp(d.oh + dy, 240, window.innerHeight - MENUBAR_H - 60) };
      }));
    };
    const up = () => {
      dragRef.current = null;
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }, [focusWin]);
  const focusedWin = windows.reduce((top, w) => !w.min && (!top || w.z > top.z) ? w : top, null);
  const dispatcher = {
    openApp: async (p) => {
      if (!openApp(p.appName)) throw new Error(`App unbekannt: ${p.appName}`);
    },
    closeApp: async (p) => {
      closeApp(p.appName);
    },
    interactWithApp: async (p) => {
      const app = String(p.appName ?? "").toLowerCase();
      if (app === "forge" && p.action === "write_code") {
        openApp("Forge");
        const content = typeof p.params?.content === "string" ? p.params.content : JSON.stringify(p.params ?? {});
        setForgeContent(`// \u2014 vom Egregore in die Esse geh\xE4mmert \u2014
${content}
`);
        return;
      }
      inscribe({ type: "APP_INTERACTION", msg: `${p.appName} \xB7 ${p.action}`, tone: "dim" });
    },
    triggerAlchemy: async (p) => {
      doAlchemy(p.type, p.intensity);
    },
    queryEngineState: async () => {
      openApp("Crucible");
      inscribe({ type: "ENGINE_QUERY", msg: "Crucible-Vitalwerte gelesen.", tone: "dim" });
    },
    observeSystem: async () => {
      openApp("Alchemy");
    }
  };
  const summonEgregore = useCallback(async (userText) => {
    if (!userText.trim() || egregoreBusy) return;
    setEgregoreBusy(true);
    setEgregoreLog((prev) => [...prev, { role: "user", text: userText }]);
    const state = coreRef.current;
    const systemState = {
      autonomyLevel: state.autonomyLevel,
      openApps: windowsRef.current.filter((w) => !w.min).map((w) => w.app),
      alchemy: state.alchemy,
      crucible: { health: state.crucible.health, activeRules: CRUCIBLE_RULES.filter((r) => r.active).length },
      corruption: state.corruption,
      recentLedger: ledgerRef.current.slice(-5).map((e) => `${e.type}: ${e.msg}`)
    };
    let raw = "";
    try {
      const response = await fetch(EGREGORE_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: EGREGORE_MODEL,
          max_tokens: EGREGORE_MAX_TOKENS,
          system: EGREGORE_SYSTEM_PROMPT,
          messages: [
            ...apiHistoryRef.current.slice(-6),
            { role: "user", content: `${serializeSystemState(systemState)}

${userText}` }
          ]
        })
      });
      const data = await response.json();
      raw = (data.content ?? []).filter((b) => b.type === "text").map((b) => b.text ?? "").join("\n");
    } catch {
      setEgregoreLog((prev) => [...prev, { role: "egregore", text: ERROR_NARRATIVES.NETWORK }]);
      inscribe({ type: "EGREGORE_ERROR", msg: "NETWORK", tone: "blood" });
      setEgregoreBusy(false);
      return;
    }
    apiHistoryRef.current = [
      ...apiHistoryRef.current,
      { role: "user", content: userText },
      { role: "assistant", content: raw }
    ].slice(-6);
    const parsed = parseEgregoreResponse(raw);
    if (!parsed.ok) {
      setEgregoreLog((prev) => [...prev, { role: "egregore", text: parsed.narrative, thinking: parsed.thinking }]);
      inscribe({ type: "EGREGORE_ERROR", msg: parsed.error, tone: "blood" });
      setEgregoreBusy(false);
      return;
    }
    let vetoed = null;
    let fractured = null;
    let hadHighIntensity = false;
    for (const action of parsed.actions) {
      const gate = regulatorGate(action, coreRef.current.autonomyLevel);
      if (!gate.allowed) {
        vetoed = gate.verdict;
        setVetoFlash((k) => k + 1);
        inscribe({ type: "REGULATOR_VETO", msg: `${action.action} \u2014 ${gate.verdict}`, tone: "blood" });
        summonWitness();
        break;
      }
      if (action.narrative) setEgregoreLog((prev) => [...prev, { role: "system", text: action.narrative }]);
      try {
        if (action.action === "wait") {
          await sleep(clamp(action.params?.ms ?? 800, 300, 3e3));
        } else {
          await dispatcher[action.action](action.params);
        }
        if (action.action === "triggerAlchemy" && (action.params?.intensity ?? 0) >= 4) hadHighIntensity = true;
      } catch (err) {
        fractured = String(err?.message ?? err);
        inscribe({ type: "RITUAL_FRACTURE", msg: `${action.action} \u2014 ${fractured}`, tone: "blood" });
        break;
      }
    }
    const finalText = vetoed ? `${speak("vetoPrefix", coreRef.current.autonomyLevel)} ${vetoed}` : fractured ? "Das Ritual zerbrach an der Materie. Der Riss ist im Ledger verzeichnet." : parsed.narrative || "Das Werk ist vollzogen.";
    setEgregoreLog((prev) => [...prev, { role: "egregore", text: finalText, thinking: parsed.thinking }]);
    if (hadHighIntensity) summonWitness();
    setEgregoreBusy(false);
  }, [egregoreBusy, inscribe, summonWitness, openApp, closeApp, doAlchemy]);
  useEffect(() => {
    const onKey = (e) => {
      const meta = e.metaKey || e.ctrlKey;
      if (!meta) return;
      if (e.key.toLowerCase() === "w") {
        const top = windowsRef.current.reduce((t, w) => !w.min && (!t || w.z > t.z) ? w : t, null);
        if (top) {
          e.preventDefault();
          closeWin(top.id);
        }
      } else if (e.key.toLowerCase() === "m") {
        const top = windowsRef.current.reduce((t, w) => !w.min && (!t || w.z > t.z) ? w : t, null);
        if (top) {
          e.preventDefault();
          minimizeWin(top.id);
        }
      } else if (/^[1-9]$/.test(e.key)) {
        const app = HOTKEY_APPS[Number(e.key) - 1];
        if (app) {
          e.preventDefault();
          try {
            openApp(app);
          } catch {
          }
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [closeWin, minimizeWin, openApp]);
  const corr = core.corruption;
  const jitter = corr >= 70;
  const visibleWindows = windows.filter((w) => !w.min);
  const dockApps = [...DOCK_CORE, ...core.installedApps];
  const ctx = {
    core,
    ledger,
    pulseKey,
    paintFiles,
    stats,
    now,
    forgeContent,
    setForgeContent,
    egregoreLog,
    egregoreBusy,
    summonEgregore,
    doAlchemy,
    petitionRaise,
    lowerAutonomy,
    purify,
    stabilizeCrucible,
    installApp,
    savePaintFile,
    deletePaintFile,
    openApp: (n) => {
      try {
        return openApp(n);
      } catch {
        return false;
      }
    },
    focusedApp: focusedWin?.app ?? null
  };
  if (phase === "boot") {
    return <div className="omega-root" style={{ position: "fixed", inset: 0, background: "#060608", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: FONT_SYS, zIndex: 0 }}>
        <style>{GLOBAL_CSS}</style>
        <div style={{ fontFamily: FONT_DISPLAY, fontSize: 84, color: GOLD, lineHeight: 1, animation: "omegaBootIn 700ms ease both" }}>Ω</div>
        <div style={{ marginTop: 28, width: 180, height: 4, borderRadius: 2, background: "rgba(255,255,255,0.10)", overflow: "hidden" }}>
          <div style={{ width: `${(bootStep + 1) * 33}%`, height: "100%", borderRadius: 2, background: GOLD, transition: "width 700ms ease" }} />
        </div>
        <div style={{ marginTop: 18, minHeight: 24, fontSize: 14, color: TEXT_SEC, fontStyle: "italic", fontFamily: FONT_DISPLAY, animation: bootStep >= 1 ? "omegaBootIn 500ms ease both" : "none", opacity: bootStep >= 1 ? 1 : 0 }}>
          {bootStep >= 2 ? speak("boot", core.autonomyLevel) : bootStep >= 1 ? "OMEGA OS" : ""}
        </div>
      </div>;
  }
  return <div className="omega-root" style={{ position: "fixed", inset: 0, overflow: "hidden", userSelect: "none", background: "#08080A", fontFamily: FONT_SYS, color: TEXT_PRI }} onPointerDown={() => setOpenMenu(null)}>
      <style>{GLOBAL_CSS}</style>

      {
    /* Cinematic bokeh background */
  }
      <div aria-hidden style={{ position: "absolute", inset: 0, pointerEvents: "none", background: [
    "radial-gradient(640px 420px at 68% 62%, rgba(190,150,70,0.10), transparent 70%)",
    "radial-gradient(480px 360px at 30% 78%, rgba(160,120,60,0.07), transparent 70%)",
    "radial-gradient(380px 300px at 82% 24%, rgba(120,100,70,0.05), transparent 70%)",
    "radial-gradient(1200px 800px at 50% 40%, rgba(20,20,26,0.5), transparent 80%)"
  ].join(",") }} />
      <div aria-hidden style={{ position: "absolute", width: 8, height: 8, borderRadius: "50%", background: "rgba(217,180,91,0.5)", filter: "blur(3px)", left: "58%", top: "70%", pointerEvents: "none" }} />
      <div aria-hidden style={{ position: "absolute", width: 5, height: 5, borderRadius: "50%", background: "rgba(217,180,91,0.35)", filter: "blur(2px)", left: "73%", top: "52%", pointerEvents: "none" }} />

      <MenuBar
    now={now}
    openMenu={openMenu}
    setOpenMenu={setOpenMenu}
    focusedTitle={focusedWin ? appMeta(focusedWin.app).title : "OMEGA"}
    windows={windows}
    autonomy={core.autonomyLevel}
    actions={{
      openApp: (n) => {
        try {
          openApp(n);
        } catch {
        }
      },
      closeFocused: () => {
        if (focusedWin) closeWin(focusedWin.id);
      },
      minimizeFocused: () => {
        if (focusedWin) minimizeWin(focusedWin.id);
      },
      zoomFocused: () => {
        if (focusedWin) toggleMaxWin(focusedWin.id);
      },
      focusWinById: focusWin,
      purify,
      stabilize: stabilizeCrucible
    }}
  />

      {
    /* Desktop icons (left) */
  }
      <div style={{ position: "absolute", left: 18, top: MENUBAR_H + 18, display: "flex", flexDirection: "column", gap: 18, zIndex: 1 }}>
        {DESKTOP_ICONS.map((ic) => <DesktopIcon key={ic.app} label={ic.label} glyph={appMeta(ic.app).glyph} onOpen={() => {
    try {
      openApp(ic.app);
    } catch {
    }
  }} />)}
      </div>

      {
    /* Windows */
  }
      <div style={{ position: "absolute", inset: 0, top: MENUBAR_H }}>
        {visibleWindows.map((w) => <MacWindow
    key={w.id}
    win={w}
    meta={appMeta(w.app)}
    focused={focusedWin?.id === w.id}
    onFocus={() => focusWin(w.id)}
    onClose={() => closeWin(w.id)}
    onMin={() => minimizeWin(w.id)}
    onZoom={() => toggleMaxWin(w.id)}
    onGesture={startWinGesture}
  >
            {renderApp(w.app, ctx)}
          </MacWindow>)}
      </div>

      {
    /* Right sidebar */
  }
      <Sidebar now={now} stats={stats} windows={windows} focusedApp={focusedWin?.app ?? null} onFocusApp={(id) => focusWin(id)} corruption={corr} jitter={jitter} />

      {
    /* Dock */
  }
      <Dock apps={dockApps} openApps={windows.map((w) => w.app)} onLaunch={(a) => {
    try {
      openApp(a);
    } catch {
    }
  }} />

      {
    /* Subtle corruption noise (only at very high values, macOS-decent) */
  }
      {corr >= 55 && <svg aria-hidden style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", opacity: Math.min(0.08, (corr - 55) / 100 * 0.18), zIndex: 4500, mixBlendMode: "screen" }}>
          <filter id="omegaNoiseMac"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch" /><feColorMatrix type="matrix" values="0 0 0 0 0.85  0 0 0 0 0.71  0 0 0 0 0.36  0 0 0 0.5 0" /></filter>
          <rect width="100%" height="100%" filter="url(#omegaNoiseMac)" />
        </svg>}

      {
    /* Veto flash */
  }
      {vetoFlash > 0 && <div key={vetoFlash} aria-hidden style={{ position: "absolute", inset: 0, pointerEvents: "none", zIndex: 4600, animation: "omegaVeto 900ms ease both" }} />}

      {
    /* The Witness */
  }
      {witness && <div key={witness.key} style={{ position: "absolute", left: 0, right: 0, top: "24%", display: "flex", justifyContent: "center", pointerEvents: "none", zIndex: 4700 }}>
          <div style={{ fontFamily: FONT_DISPLAY, fontStyle: "italic", fontSize: 22, color: "#EDE9DC", letterSpacing: "0.06em", textShadow: "0 0 22px rgba(217,180,91,0.35)", animation: "omegaWitness 4.6s ease both" }}>
            {witness.text}
          </div>
        </div>}
    </div>;
}
