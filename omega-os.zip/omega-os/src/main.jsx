import React from "react";
import { createRoot } from "react-dom/client";
import OmegaOS from "./OmegaOS.jsx";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <OmegaOS />
  </React.StrictMode>
);
