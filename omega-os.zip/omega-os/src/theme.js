const GOLD = "#D9B45B";
const GOLD_SOFT = "#B89B55";
const GOLD_BTN = "#E2BC60";
const GOLD_BTN_HOVER = "#F0CC78";
const INK_ON_GOLD = "#2B2412";
const TEXT_PRI = "#F2F2F4";
const TEXT_SEC = "#9A9AA0";
const TEXT_TER = "#6E6E74";
const BLOOD = "#C25B52";
const VERDIGRIS = "#5E9A87";
const WIN_BG = "rgba(28,28,30,0.78)";
const TITLE_BG = "rgba(44,44,46,0.55)";
const CARD_BG = "rgba(255,255,255,0.045)";
const CARD_BG_HOVER = "rgba(255,255,255,0.07)";
const HAIRLINE = "rgba(255,255,255,0.08)";
const HAIRLINE_SOFT = "rgba(255,255,255,0.055)";
const TL_RED = "#FF5F57";
const TL_YELLOW = "#FEBC2E";
const TL_GREEN = "#28C840";
const TL_IDLE = "#4D4D50";
const FONT_SYS = "-apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif";
const FONT_DISPLAY = "'Cormorant Garamond', Georgia, serif";
const FONT_MONO = "ui-monospace, 'SF Mono', Menlo, Consolas, monospace";
const MENUBAR_H = 26;
const DOCK_ZONE = 92;

export const APP_PAD = { height: "100%", overflowY: "auto", padding: "14px 16px" };

export {
  GOLD, GOLD_SOFT, GOLD_BTN, GOLD_BTN_HOVER, INK_ON_GOLD,
  TEXT_PRI, TEXT_SEC, TEXT_TER, BLOOD, VERDIGRIS,
  WIN_BG, TITLE_BG, CARD_BG, CARD_BG_HOVER, HAIRLINE, HAIRLINE_SOFT,
  TL_RED, TL_YELLOW, TL_GREEN, TL_IDLE,
  FONT_SYS, FONT_DISPLAY, FONT_MONO, MENUBAR_H, DOCK_ZONE
};
