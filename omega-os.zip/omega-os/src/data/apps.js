const CORE_APPS = {
  AppStore: { title: "App Store", glyph: "\u24B6", w: 660, h: 540 },
  Egregore: { title: "Egregore", glyph: "\u03A9", w: 470, h: 560 },
  Crucible: { title: "Crucible", glyph: "\u25B3", w: 420, h: 480 },
  Forge: { title: "Forge", glyph: "\u2692", w: 460, h: 420 },
  Ledger: { title: "Ledger", glyph: "\u2263", w: 480, h: 500 },
  Alchemy: { title: "Alchemy", glyph: "\u2609", w: 400, h: 380 },
  Regulator: { title: "Regulator", glyph: "\u25C9", w: 420, h: 540 },
  Files: { title: "Files", glyph: "\u25A4", w: 520, h: 420 },
  Terminal: { title: "Terminal", glyph: "\u276F", w: 560, h: 400 },
  Browser: { title: "Browser", glyph: "\u25CD", w: 600, h: 460 },
  About: { title: "About OMEGA", glyph: "\u24D8", w: 380, h: 440 }
};
const STORE_APPS = [
  { id: "Weather", title: "Weather", category: "LIFESTYLE", glyph: "\u2601", desc: "Clean, glanceable forecasts in the OMEGA aesthetic.", meta: { title: "Weather", glyph: "\u2601", w: 420, h: 480 } },
  { id: "WorldClock", title: "World Clock", category: "UTILITIES", glyph: "\u25D4", desc: "Live time across Berlin, New York, Tokyo and London.", meta: { title: "World Clock", glyph: "\u25D4", w: 420, h: 420 } },
  { id: "Dice", title: "Dice", category: "GAMES", glyph: "\u2684", desc: "A tactile pair of dice with a satisfying roll.", meta: { title: "Dice", glyph: "\u2684", w: 360, h: 380 } },
  { id: "Game2048", title: "2048", category: "GAMES", glyph: "\u2317", desc: "The classic tile-merging puzzle \u2014 fully playable, in gold.", meta: { title: "2048", glyph: "\u2317", w: 400, h: 540 } },
  { id: "Paint", title: "Paint", category: "CREATIVE", glyph: "\u270E", desc: "A real drawing canvas \u2014 brushes, gold palette, save to Files.", meta: { title: "Paint", glyph: "\u270E", w: 640, h: 520 } },
  { id: "SynthPad", title: "Synth Pad", category: "CREATIVE", glyph: "\u266A", desc: "A playable 16-pad synthesizer with real Web Audio tones.", meta: { title: "Synth Pad", glyph: "\u266A", w: 420, h: 500 } }
];
const STORE_BY_ID = Object.fromEntries(STORE_APPS.map((a) => [a.id, a]));
function appMeta(app) {
  return CORE_APPS[app] ?? STORE_BY_ID[app]?.meta ?? { title: app, glyph: "\u25A1", w: 420, h: 360 };
}
const DESKTOP_ICONS = [
  { app: "Files", label: "Files" },
  { app: "Terminal", label: "Terminal" },
  { app: "Browser", label: "Browser" },
  { app: "About", label: "About OMEGA" }
];
const DOCK_CORE = ["AppStore", "Egregore", "Crucible", "Forge", "Ledger", "Alchemy", "Regulator", "Files", "Terminal", "Browser"];
const HOTKEY_APPS = ["AppStore", "Egregore", "Crucible", "Forge", "Ledger", "Alchemy", "Regulator", "Files", "Terminal"];

export { CORE_APPS, STORE_APPS, STORE_BY_ID, appMeta, DESKTOP_ICONS, DOCK_CORE, HOTKEY_APPS };
