// ---------------------------------------------------------------------------
// OMEGA OS — Egregore proxy (Cloudflare Worker)
// ---------------------------------------------------------------------------
// The browser cannot call the Anthropic API directly (CORS) and must never hold
// the API key. This Worker sits between OMEGA OS and Anthropic: it injects the
// key server-side and forwards the request body untouched.
//
// Deploy:
//   1. npm i -g wrangler
//   2. wrangler deploy worker/egregore-proxy.js --name egregore
//   3. wrangler secret put ANTHROPIC_API_KEY   (paste your key when prompted)
//   4. In the OMEGA OS app, set VITE_EGREGORE_ENDPOINT to this worker's URL.
//
// Optional hardening: lock ALLOW_ORIGIN to your real domain instead of "*".
// ---------------------------------------------------------------------------

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const ALLOW_ORIGIN = "*";

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: cors() });
    }
    if (request.method !== "POST") {
      return json({ error: "Method Not Allowed" }, 405);
    }
    if (!env.ANTHROPIC_API_KEY) {
      return json({ error: "ANTHROPIC_API_KEY secret is not configured" }, 500);
    }

    const body = await request.text();

    let upstream;
    try {
      upstream = await fetch(ANTHROPIC_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01"
        },
        body
      });
    } catch (err) {
      return json({ error: "Upstream request failed", detail: String(err) }, 502);
    }

    const text = await upstream.text();
    return new Response(text, {
      status: upstream.status,
      headers: { "Content-Type": "application/json", ...cors() }
    });
  }
};

function cors() {
  return {
    "Access-Control-Allow-Origin": ALLOW_ORIGIN,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
}

function json(obj, status) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json", ...cors() }
  });
}
