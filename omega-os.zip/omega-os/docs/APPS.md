# App-Katalog

OMEGA OS enthält 17 voll funktionale Apps. Elf sind **Core-Apps** (immer im Dock), sechs sind **Store-Apps** (erst über den App Store installierbar).

Jede App lebt in einer eigenen Datei unter `src/apps/` und wird über `apps/index.jsx` per `renderApp(app, ctx)` aufgelöst.

---

## Core-Apps

### Ω Egregore — `EgregoreApp.jsx`
Das Chat-Interface zum gebundenen KI-Agenten. Nachrichten lösen `summonEgregore()` aus; Antworten erscheinen in sakraler Schrift, mit ausklappbarem `PROTOKOLL` (dem `<thinking>`-Block). Voll erklärt in [EGREGORE.md](./EGREGORE.md).

### ◉ Regulator — `RegulatorApp.jsx`
Die Governance-Konsole. Zeigt die Autonomie-Stufe, erlaubt **Petition: Erheben** (mit Erwägungs-Verzögerung) und **Senken (frei)**, visualisiert Korruption und bietet das **Reinigungsritual**. Die Asymmetrie in Aktion.

### △ Crucible — `CrucibleApp.jsx`
Das Gefäß. Zeigt die Crucible-Gesundheit, listet die sechs Gesetze der Charta und erlaubt **Stabilisieren (+15)**.

### ☰ Ledger — `LedgerApp.jsx`
Das unwiderrufliche Protokoll. Jede Inschrift mit Typ, Zeitstempel und farbcodiertem Ton (Gold/Blut/Grünspan/Gedämpft). Persistent über Reloads.

### ☉ Alchemy — `AlchemyApp.jsx`
Die vier Werke als Zähler-Raster: **Coagula** (create), **Solve** (dissolve), **Transmutatio** (transmute), **Genesis**. Jede Zählung pulsiert bei Auslösung.

### ⚒ Forge — `ForgeApp.jsx`
Ein Code-Editor („die Esse"). Der Egregore kann via `write_code` direkt hineinschreiben. Der Knopf **Transmutieren · Coagula II** löst Alchemie der Intensität 2 aus.

### Ⓐ App Store — `AppStoreApp.jsx`
Der Katalog der Store-Apps mit Live-Suche. **Get** installiert (und fügt dem Dock hinzu, löst Coagula aus), **Open** startet.

### ▤ Files — `FilesApp.jsx`
Die Galerie gespeicherter Paint-Bilder („Inschriften", max. 6). Vorschau, Zeitstempel, Löschen.

### ❯ Terminal — `TerminalApp.jsx`
Eine echte Befehlszeile mit Zugriff auf den System-Zustand. Befehle lesen Core-Werte und können Alchemie/Reinigung/Stabilisierung auslösen.

### ◍ Browser — `BrowserApp.jsx`
Ein stilisierter Browser im OMEGA-Look.

### ⓘ About OMEGA — `AboutApp.jsx`
Das Kolophon — Version, Wesen und Leitsatz des Systems.

---

## Store-Apps

| App | Datei | Kategorie | Wesen |
|---|---|---|---|
| ☁ Weather | `WeatherApp.jsx` | Lifestyle | Glanzlose 5-Tage-Vorschau (Feld-Simulation, kein Live-Feed) |
| ◔ World Clock | `WorldClockApp.jsx` | Utilities | Live-Zeit für Berlin, New York, Tokio, London |
| ⚄ Dice | `DiceApp.jsx` | Games | Zwei Würfel mit Roll-Animation; jeder Wurf eine kleine Transmutation |
| ⌗ 2048 | `Game2048App.jsx` | Games | Voll spielbares Kachel-Puzzle (Pfeiltasten); Kachel ≥ 128 nährt Coagula |
| ✎ Paint | `PaintApp.jsx` | Creative | Echtes Canvas mit Pinseln, Gold-Palette, Speichern in Files |
| ♪ Synth Pad | `SynthPadApp.jsx` | Creative | 16-Pad-Synthesizer mit echten Web-Audio-Tönen (A-Moll-Pentatonik) |

---

## Eine neue App hinzufügen

Drei Schritte:

1. **Komponente** — `src/apps/MyApp.jsx` anlegen. Sie bekommt `{ ctx }` als Prop und gibt JSX zurück. `APP_PAD` aus `theme.js` gibt den Standard-Innenabstand.

   ```jsx
   import React from "react";
   import { GOLD, APP_PAD } from "../theme.js";

   function MyApp({ ctx }) {
     return <div style={{ ...APP_PAD }}>
       <div style={{ color: GOLD }}>Autonomie: {ctx.core.autonomyLevel}</div>
     </div>;
   }
   export { MyApp };
   ```

2. **Registry** — in `src/data/apps.js` Metadaten ergänzen. Als Core-App nach `CORE_APPS` (und optional in `DOCK_CORE`); als Store-App nach `STORE_APPS`.

   ```js
   MyApp: { title: "My App", glyph: "✦", w: 460, h: 420 }
   ```

3. **Dispatcher** — in `src/apps/index.jsx` importieren und einen `case` ergänzen:

   ```jsx
   import { MyApp } from "./MyApp.jsx";
   // …
   case "MyApp": return <MyApp ctx={ctx} />;
   ```

Fertig. Die Shell (Fenster, Dock, Hotkeys) übernimmt den Rest automatisch.

---

## Welche Apps berühren die Engine?

Manche Apps sind reine Anzeigen, andere greifen aktiv in die Governance ein:

| App | Effekt auf den Zustand |
|---|---|
| Egregore | löst beliebige Aktionen über den Regulator aus |
| Regulator | Petition, Senken, Reinigung |
| Crucible | Stabilisierung |
| Forge | Coagula (Intensität 2) |
| App Store | Installation → Coagula (Intensität 1) |
| Paint | Speichern → Coagula (Intensität 1) |
| Dice | Wurf → Transmutatio (Intensität 1) |
| 2048 | Kachel ≥ 128 → Coagula (Intensität 1) |
| Terminal | je nach Befehl |
| übrige | nur Anzeige |
