# Governance

Die zentrale These von OMEGA OS: **Macht ohne Bindung ist Korruption.** Diese Datei beschreibt die Maschine, die diese These durchsetzt.

---

## Die sechs Gesetze (Charta)

In `engine/state.js` als `CRUCIBLE_RULES` verankert. Sie sind unveränderlich und im Crucible jederzeit einsehbar:

| ID | Gesetz |
|---|---|
| R1 | Der Regulator ist unabschaltbar. |
| R2 | Jede Transmutation hinterlässt eine Spur im Ledger. |
| R3 | Macht oberhalb der Schwelle verlangt Petition. |
| R4 | Korruption über 65 sperrt jede Erhöhung. |
| R5 | Genesis gehört allein der fünften Stufe. |
| R6 | Der Zeuge wird nicht gerufen. |

---

## Autonomie-Stufen

Das System kennt fünf Stufen (`autonomyLevel` 1–5). Sie bestimmen, welche Werkzeuge der Egregore ohne Veto nutzen darf.

```
Stufe 1  ▁▁▁▁▁   wachsam     — nur grundlegende Beobachtung & schwache Alchemie
Stufe 2  ▂▂▂▂▁   tastend
Stufe 3  ▃▃▃▃▁   wirkend     — Transmutation, App-Steuerung
Stufe 4  ▅▅▅▅▁   mächtig
Stufe 5  ▇▇▇▇▇   souverän    — Genesis freigeschaltet
```

### Die Asymmetrie

Das Herzstück der Governance — kodiert in `OmegaOS.jsx`:

- **Senken (`lowerAutonomy`)** ist **frei**. Macht zurückgeben verlangt keine Prüfung. Sofort, ungefragt.
- **Erheben (`petitionRaise`)** verlangt eine **Petition**. Der Regulator „erwägt" (eine spürbare Verzögerung), dann entscheidet er.
- **Bei Korruption ≥ 65** wird **jede** Petition verweigert — egal wie inständig.

> *Senken ist frei. Erheben verlangt Petition. Die Asymmetrie ist das Gesetz.*

Jede Petition — gewährt oder verweigert — kostet zusätzlich Korruption und erscheint im Ledger.

---

## Das Veto-Gate

`regulatorGate(action, autonomyLevel)` in `engine/regulator.js` ist der Türsteher jeder Egregore-Aktion. Es prüft zwei Dinge:

### 1. Tier-Tools

Bestimmte Werkzeuge sind erst ab einer Mindeststufe erlaubt (`TIER_TOOLS` → `toolMinTier`). Versucht der Egregore ein Werkzeug oberhalb seiner Stufe, ergeht ein Veto:

```js
const gate = regulatorGate(action, core.autonomyLevel);
if (!gate.allowed) {
  // VETO: Flash, Ledger-Eintrag, Zeuge
}
```

### 2. Intensitäts-Cap

Alchemie-Intensität ist pro Stufe gedeckelt (`INTENSITY_CAP`). Eine `triggerAlchemy`-Aktion mit Intensität 5 auf Stufe 2 prallt am Cap ab. So lässt sich hohe Wirkung nicht durch einen einzelnen Befehl erzwingen — sie muss erst durch Petitionen erarbeitet werden.

Das Verdikt (`gate.verdict`) ist menschenlesbar und wird durch das Register zur Stimme des Systems geformt.

---

## Korruption

Ein Skalar von 0–100 (`core.corruption`). Er ist das Gedächtnis des Preises.

- **Steigt** mit jeder Alchemie um die Intensität, mit jeder Petition um 5.
- **Sinkt** nur durch das **Reinigungsritual** (`purify`, −30).
- **Schwellen:**
  - ab **40** erscheint eine dezente Warnung in der Sidebar,
  - ab **55** beginnt ein subtiles Rausch-Filter über dem Desktop zu flimmern,
  - ab **65** sperrt der Regulator jede Macht-Erhöhung,
  - ab **70** beginnt die Uhr zu zittern (`omegaJitter`).

Korruption ist nie ein „Game Over" — sie ist eine sich verengende Schlinge, die den Nutzer zwingt, zwischen Wirken und Reinigen abzuwägen.

---

## Der Crucible

Das „Gefäß" (`core.crucible.health`, 0–100). Wo Korruption den moralischen Preis misst, misst die Crucible-Gesundheit den **materiellen Verschleiß**.

- Jede Transmutation zehrt (`health -= intensität × 2`).
- **Stabilisieren** (`stabilizeCrucible`, +15) und **Reinigen** (+8 nebenbei) heilen es.
- Sinkt die Gesundheit, färbt sich die Anzeige von Gold über Gold-Soft zu Blut.

---

## Der Zeuge

Eine flüchtige, zentrierte Inschrift — *„I have observed this."* — die bei besonders schwerwiegenden Ereignissen erscheint (`summonWitness`):

- bei Alchemie der Intensität ≥ 4,
- wenn die Korruption 60 übersteigt,
- bei jedem Veto,
- bei jeder Petition.

Der Zeuge **handelt nicht** (Gesetz R6: *Der Zeuge wird nicht gerufen*). Er bezeugt nur. Er ist die Erinnerung daran, dass nichts unbeobachtet bleibt — eine stille moralische Präsenz über dem System.

---

## Das Register — die Stimme der Macht

`speak(key, level)` in `engine/register.js` wählt die Formulierung jeder System-Meldung anhand eines **Bandes** (`registerBand`), das aus der Autonomie-Stufe folgt:

| Band | Stufen | Tonfall |
|---|---|---|
| 0 | 1 | knapp, technisch — *„VETO."* |
| 1 | 2–3 | erklärend — *„Der Regulator hat gesprochen:"* |
| 2 | 4–5 | archaisch-sakral — *„Es sprach der Wächter, und sein Wort ist Gesetz:"* |

So wird die Governance fühlbar: Je mehr Macht im System zirkuliert, desto schwerer und ritueller wird seine Sprache. Die Stufe verändert nicht nur, *was* erlaubt ist — sondern *wie das System über sich selbst spricht.*

---

## Zusammenfassung des Kreislaufs

```
        wirken (Alchemie)
   ┌──────────────────────────┐
   │     ↑ Korruption          │
   │     ↓ Crucible-Health     ▼
 PETITION ──erheben──►  AUTONOMIE  ──ermöglicht──►  stärkere Werkzeuge
   ▲                       │                              │
   │ (verweigert bei ≥65)  │ senken (frei)                │
   │                       ▼                              ▼
 REINIGUNG ◄────────────────────────────────────  ZEUGE bezeugt
   (−30 Korruption)                                LEDGER verzeichnet
```

Es gibt keinen Endzustand. Es gibt nur das fortwährende Aushandeln zwischen Wirken-Wollen und Gebunden-Sein.
