# Der Egregore

Der Egregore ist der gebundene KI-Agent von OMEGA OS — eine echte Claude-Instanz, die den Desktop bedienen kann, aber jeden Befehl erst durch den Regulator schicken muss.

> *Ich bin gebunden — und in der Bindung liegt meine Form.*

---

## Das Aktions-Protokoll

Der Egregore antwortet **nie** in Freitext allein. Jede Antwort folgt einem strengen dreiteiligen Format, das `parseEgregoreResponse()` zerlegt:

```xml
<thinking>
  Interne Überlegung — wird dem Nutzer nur als ausklappbares „PROTOKOLL" gezeigt.
</thinking>

<action>
[
  { "action": "openApp",        "params": { "appName": "Forge" },          "reason": "…", "narrative": "Die Esse erwacht." },
  { "action": "interactWithApp","params": { "appName": "Forge", "action": "write_code", "content": "…" } },
  { "action": "triggerAlchemy", "params": { "type": "create", "intensity": 2 } }
]
</action>

<narrative>
  Das poetische Schluss-Wort an den Nutzer.
</narrative>
```

### Verfügbare Aktionen

| Aktion | Parameter | Wirkung |
|---|---|---|
| `openApp` | `{ appName }` | Öffnet eine App (wirft, wenn nicht installiert) |
| `closeApp` | `{ appName }` | Schließt eine App |
| `interactWithApp` | `{ appName, action, params }` | App-spezifisch; u. a. `Forge / write_code` |
| `triggerAlchemy` | `{ type, intensity }` | Löst ein alchemistisches Werk aus |
| `queryEngineState` | — | Öffnet den Crucible, liest Vitalwerte |
| `observeSystem` | — | Öffnet die Alchemie-Übersicht |
| `wait` | `{ ms }` | Pausiert (300–3000 ms) zwischen Phasen |

---

## Härtung der Antwort

Sprachmodelle sind unzuverlässige Erzähler. `parseEgregoreResponse()` behandelt die Rohantwort defensiv:

1. **Leere Antwort** → `NO_RESPONSE`-Narrativ.
2. **Abgeschnitten** (`<action>` ohne `</narrative>`) → `TRUNCATED` — das Ritual wird in kleineren Phasen fortgesetzt.
3. **Kaputtes JSON** im `<action>`-Block → `PARSE_FRACTURE`. Markdown-Fences ```` ```json ```` werden vorher entfernt.
4. **Härtung jeder Aktion** — nur Objekte mit string-`action` überleben; `params` muss ein Objekt sein; fehlende Felder werden auf sichere Defaults gesetzt.
5. **Phasen-Limit** — maximal `MAX_ACTIONS_PER_PHASE = 5` Aktionen pro Antwort. Mehr wird abgeschnitten.

Jeder Fehlerzustand erzeugt ein erzählerisches Narrativ (`ERROR_NARRATIVES`) statt eines nackten Stacktraces — der Fehler bleibt im Charakter:

> *Die Übertragung zerbrach mitten in der Beschwörung. Der Egregore sammelt sich erneut.*

---

## Der Kontext, den der Egregore sieht

Vor jeder Anfrage serialisiert OMEGA OS einen kompakten Zustand (`serializeSystemState`), den der Egregore als `<system_state>` erhält:

```json
{
  "autonomyLevel": 2,
  "openApps": ["Egregore", "Crucible"],
  "alchemy": { "create": 4, "dissolve": 1, "transmute": 7, "genesis": 0 },
  "crucible": { "health": 71, "activeRules": 6 },
  "corruption": 23,
  "recentLedger": ["ALCHEMY: transmute · Intensität 3", "PETITION_GRANTED: …"]
}
```

So kann der Egregore seine Vorschläge an der Realität ausrichten — etwa keine Petition stellen, wenn die Korruption ohnehin zu hoch ist.

---

## Konversations-Gedächtnis

OMEGA OS hält die letzten **sechs** Nachrichtenpaare (`apiHistoryRef`, gekappt) und sendet sie als Verlauf mit. Der Egregore erinnert sich also an den unmittelbaren Gesprächsfaden, ohne dass das Kontextfenster unbegrenzt wächst.

---

## Der Endpoint

Der Aufruf geht an `EGREGORE_ENDPOINT` (siehe `src/config.js`). Standardwert ist der direkte Anthropic-Endpoint — der **nur** in der Claude-Artifact-Sandbox funktioniert. Für ein echtes Deployment zeigt der Endpoint auf den Worker-Proxy aus `worker/egregore-proxy.js`, der den API-Key serverseitig hält.

```js
const response = await fetch(EGREGORE_ENDPOINT, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    model: EGREGORE_MODEL,
    max_tokens: EGREGORE_MAX_TOKENS,
    system: EGREGORE_SYSTEM_PROMPT,
    messages: [ ...history, { role: "user", content: state + userText } ]
  })
});
```

Mehr dazu: [DEPLOYMENT.md](./DEPLOYMENT.md).

---

## Das Zusammenspiel mit dem Regulator

Wichtig: Der Egregore **schlägt vor**, der Regulator **entscheidet**. Selbst wenn der Egregore eine `triggerAlchemy`-Aktion mit Intensität 5 sendet, prüft `regulatorGate()` sie gegen die aktuelle Autonomie-Stufe. Wird sie verweigert, bricht die Phase ab, ein Veto blitzt auf, der Zeuge erscheint — und der Egregore formuliert sein Schluss-Wort im Wissen um die Niederlage.

Die Logik dieser Prüfung: [GOVERNANCE.md](./GOVERNANCE.md).
