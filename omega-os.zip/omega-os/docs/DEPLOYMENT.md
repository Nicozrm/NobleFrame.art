# Deployment

OMEGA OS läuft in zwei Welten. Diese Datei erklärt beide und vor allem, wie der Egregore in einer echten Bereitstellung lebendig wird.

---

## Die zwei Welten

| | Claude-Artifact-Sandbox | Standalone (dieses Repo) |
|---|---|---|
| Persistenz | `window.storage` | `localStorage` |
| Egregore-Endpoint | direkt zu Anthropic (sandbox-erlaubt) | **Proxy zwingend** |
| API-Key | von der Sandbox injiziert | vom Proxy gehalten |

Derselbe Code bedient beide — die Weichen stehen in `src/config.js` und `src/engine/storage.js`.

---

## Warum ein Proxy zwingend ist

Im Browser direkt zu `api.anthropic.com` zu sprechen, scheitert an zwei Wänden:

1. **CORS** — Anthropic erlaubt keine Cross-Origin-Browser-Aufrufe.
2. **Schlüssel-Sicherheit** — ein API-Key im Frontend-Bundle ist sofort kompromittiert.

Die Lösung: ein winziger serverseitiger Proxy, der den Key hält und die Anfrage durchreicht. Dieses Repo bringt ihn als Cloudflare Worker mit (`worker/egregore-proxy.js`).

---

## Schritt 1 — Den Egregore-Proxy deployen (Cloudflare Worker)

```bash
# Wrangler installieren (Cloudflare CLI)
npm i -g wrangler
wrangler login

# Worker deployen
wrangler deploy worker/egregore-proxy.js --name egregore

# Den API-Key als Secret hinterlegen (NICHT im Code!)
wrangler secret put ANTHROPIC_API_KEY
#   → Schlüssel einfügen, wenn Wrangler danach fragt
```

Wrangler gibt eine URL aus, etwa `https://egregore.dein-name.workers.dev`. Der Worker:

- nimmt nur `POST`,
- injiziert `x-api-key` und `anthropic-version` serverseitig,
- reicht den Body unverändert an Anthropic,
- setzt CORS-Header für deine Domain.

> **Härtung:** In `worker/egregore-proxy.js` `ALLOW_ORIGIN` von `"*"` auf deine echte Domain setzen, damit nicht Fremde deinen Proxy (und dein Kontingent) nutzen.

---

## Schritt 2 — Das Frontend auf den Proxy zeigen

Lege eine `.env` an (Vorlage: `.env.example`):

```bash
VITE_EGREGORE_ENDPOINT=https://egregore.dein-name.workers.dev
VITE_EGREGORE_MODEL=claude-sonnet-4-20250514
```

`src/config.js` liest diese Werte zur Build-Zeit. Ohne sie bleibt der Standard (direkter Anthropic-Endpoint) — der außerhalb der Sandbox nicht funktioniert.

---

## Schritt 3 — Bauen & ausliefern

```bash
npm install
npm run build      # → dist/
```

Das `dist/`-Verzeichnis ist statisch und passt auf jeden Host.

### Cloudflare Pages

```bash
wrangler pages deploy dist --project-name omega-os
```

Oder per Git-Integration: Build-Command `npm run build`, Output-Verzeichnis `dist`, und `VITE_EGREGORE_ENDPOINT` in den Pages-Umgebungsvariablen setzen.

### Vercel

```
Build Command:     npm run build
Output Directory:  dist
Environment:       VITE_EGREGORE_ENDPOINT = https://egregore.dein-name.workers.dev
```

### Netlify

```
Build command:     npm run build
Publish directory: dist
```

Umgebungsvariable analog im Netlify-Dashboard.

### Eigener Server / Nginx

`dist/` als statisches Root ausliefern. Wichtig: eine SPA-Fallback-Regel ist hier **nicht** nötig, da OMEGA OS keine Client-Routen nutzt.

---

## Alternative: Proxy als Vercel/Netlify Function

Wer keinen Cloudflare Worker will, kann denselben Durchreich-Mechanismus als Serverless Function bauen. Das Prinzip bleibt identisch:

```js
// api/egregore.js  (Vercel)
export default async function handler(req, res) {
  const upstream = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify(req.body)
  });
  const data = await upstream.json();
  res.status(upstream.status).json(data);
}
```

Dann `VITE_EGREGORE_ENDPOINT=/api/egregore` setzen.

---

## Checkliste vor dem Go-Live

- [ ] Worker deployt, `ANTHROPIC_API_KEY` als Secret gesetzt (nie im Code)
- [ ] `ALLOW_ORIGIN` im Worker auf die echte Domain beschränkt
- [ ] `VITE_EGREGORE_ENDPOINT` in der Host-Umgebung gesetzt
- [ ] `npm run build` läuft fehlerfrei
- [ ] `_source.tsx` und `_build.py` sind via `.gitignore` ausgeschlossen
- [ ] Egregore antwortet im deployten Build (Netzwerk-Tab prüfen: Aufruf geht an den Worker, nicht an Anthropic)
- [ ] Reload-Test: Ledger und Autonomie-Stufe bleiben erhalten

---

## Fehlerbilder

| Symptom | Ursache | Lösung |
|---|---|---|
| *„Die Verbindung zum Tiegel riss."* | Endpoint falsch/nicht erreichbar | `VITE_EGREGORE_ENDPOINT` prüfen, Worker-URL testen |
| CORS-Fehler in der Konsole | Frontend ruft Anthropic direkt | Endpoint auf den Proxy zeigen lassen |
| `500` vom Worker | Secret fehlt | `wrangler secret put ANTHROPIC_API_KEY` |
| Egregore antwortet, aber Aktionen greifen nicht | Regulator-Veto | normal — Autonomie-Stufe/Korruption prüfen |
| Zustand geht bei Reload verloren | Storage blockiert (Privatmodus o. Ä.) | anderes Profil/Browser testen |
