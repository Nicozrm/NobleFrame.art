# Architektur

OMEGA OS ist in vier Ringe geschichtet. Jeder Ring kennt nur die Ringe unter sich.

```
┌─────────────────────────────────────────────────────────┐
│  OmegaOS.jsx — Orchestrator                              │
│  State · Fenster-Manager · Egregore-Dispatcher · Hotkeys │
└───────────────┬─────────────────────────┬───────────────┘
                │                         │
        ┌───────▼────────┐       ┌────────▼─────────┐
        │  components/   │       │     apps/        │
        │  Shell-Chrome  │       │  17 Inhalte      │
        └───────┬────────┘       └────────┬─────────┘
                │                         │
        ┌───────▼─────────────────────────▼─────────┐
        │  engine/  —  reine Logik, kein React       │
        │  egregore · regulator · register · state   │
        │  · storage                                 │
        └───────┬─────────────────────────────────────┘
                │
        ┌───────▼────────┐
        │  theme · utils │
        │  data/apps     │
        └────────────────┘
```

---

## Die Ringe

### 1. Fundament — `theme.js`, `lib/utils.js`, `data/apps.js`

Reine Konstanten und Helfer ohne Abhängigkeiten.

- **`theme.js`** — die gesamte Design-Sprache: Gold-Töne (`GOLD = #D9B45B`), Blut (`BLOOD`), Grünspan (`VERDIGRIS`), Text-Hierarchie, Hairlines, Fonts (`FONT_DISPLAY` für die sakrale Stimme, `FONT_MONO` für Maschinen-Output) und Layout-Maße (`MENUBAR_H`, `DOCK_ZONE`). Zusätzlich `APP_PAD`, das geteilte Innenabstands-Objekt der Apps.
- **`lib/utils.js`** — `sleep(ms)` und `clamp(v, lo, hi)`.
- **`data/apps.js`** — die App-Registry: `CORE_APPS` (immer vorhanden), `STORE_APPS` (installierbar), `appMeta()` zur Auflösung von Name → Fenstergröße/Glyph, plus die Dock-/Desktop-/Hotkey-Listen.

### 2. Engine — `engine/*`

Die Governance-Maschine. **Vollständig UI-frei** — ließe sich als npm-Paket extrahieren und in jedem JS-Kontext testen.

| Modul | Verantwortung |
|---|---|
| `state.js` | `DEFAULT_CORE` (der Anfangszustand), `CRUCIBLE_RULES` (die sechs unveränderlichen Gesetze), `serializeSystemState()` für den KI-Kontext |
| `storage.js` | Persistenz-Schlüssel, Caps und `storageGet/Set` mit Fallback `window.storage` → `localStorage` |
| `register.js` | `speak(key, level)` — wählt je nach Autonomie-Band die Formulierung der System-Stimme |
| `regulator.js` | `regulatorGate(action, level)` — das Veto-Herz; prüft Tier-Tools & Intensitäts-Caps |
| `egregore.js` | Der System-Prompt und `parseEgregoreResponse()`, der die KI-Antwort härtet |

Details zur Engine: [GOVERNANCE.md](./GOVERNANCE.md) und [EGREGORE.md](./EGREGORE.md).

### 3. Shell — `components/*`

Wiederverwendbares Chrome ohne Geschäftslogik. `MacWindow` (mit `TrafficLight`), `Dock` (mit Magnification-Mathematik), `MenuBar`, `Sidebar` (mit `SideCard`/`StatBar`), `DesktopIcon`, `GoldButton`, `SvgIcon`. Sie bekommen alles per Props und rufen nichts aus der Engine direkt auf.

### 4. Apps — `apps/*`

Eine Datei pro Anwendung. Jede App erhält ein `ctx`-Objekt (siehe unten) und ist ansonsten autark. `apps/index.jsx` enthält den `renderApp(app, ctx)`-Dispatcher — die einzige Stelle, die alle Apps kennt.

### Spitze — `OmegaOS.jsx`

Der Orchestrator. Hält den gesamten React-State, verwaltet das Fenster-System (Z-Order, Drag/Resize, Minimize/Zoom), beherbergt den Egregore-Dispatcher und verteilt Aktionen.

---

## Das `ctx`-Objekt

Statt Prop-Drilling reicht `OmegaOS.jsx` ein einziges Kontext-Objekt an jede App. Es bündelt Zustand und Aktionen:

```js
const ctx = {
  // Zustand (read)
  core,            // { autonomyLevel, alchemy, crucible, corruption, installedApps }
  ledger,          // Array der Inschriften
  paintFiles,      // gespeicherte Paint-Bilder
  stats,           // { cpu, ram, net } (animiert)
  now,             // aktuelle Date
  pulseKey,        // Trigger für Alchemie-Pulse-Animation
  egregoreLog,     // Chatverlauf
  egregoreBusy,    // bool
  forgeContent,    // Editor-Inhalt
  focusedApp,      // Name der fokussierten App

  // Aktionen (write)
  summonEgregore,  setForgeContent,
  doAlchemy,       petitionRaise,   lowerAutonomy,
  purify,          stabilizeCrucible,
  installApp,      openApp,
  savePaintFile,   deletePaintFile
};
```

Eine App liest aus `ctx.core` und löst über z. B. `ctx.doAlchemy("create", 2)` Effekte aus, die durch den State und ins Ledger propagieren.

---

## Datenfluss einer Aktion

Am Beispiel: *Der Egregore soll eine Transmutation der Intensität 5 auslösen.*

```
1.  Nutzer  →  EgregoreApp  →  ctx.summonEgregore("…")
2.  OmegaOS  serialisiert den System-State  (serializeSystemState)
3.  fetch → EGREGORE_ENDPOINT (Proxy → Anthropic)
4.  Antwort → parseEgregoreResponse()  →  { thinking, actions[], narrative }
5.  Für jede Aktion:
        regulatorGate(action, autonomyLevel)
        ├── allowed?  → dispatcher[action.action](params)
        │              → doAlchemy("transmute", 5)
        │                 ├── core.corruption += 5
        │                 ├── crucible.health -= 10
        │                 ├── inscribe(LEDGER)         ← persistent
        │                 └── summonWitness()          ← bei i≥4
        └── verweigert? → VETO-Flash + Ledger-Eintrag + Zeuge
6.  Schluss-Narrativ → egregoreLog
```

Jeder schreibende Pfad endet in `persistCore()` (→ `storageSet`) und/oder `inscribe()` (→ Ledger + `storageSet`). **Nichts geschieht ohne Spur.**

---

## Persistenz

Drei Schlüssel, beide Speicher-Backends transparent:

| Schlüssel | Inhalt | Cap |
|---|---|---|
| `omega-core-v4` | autonomyLevel, alchemy, crucible, corruption, installedApps | — |
| `omega-ledger-v4` | Array der Inschriften | 200 Einträge |
| `omega-files-v4` | gespeicherte Paint-Bilder | 6 Dateien |

`storageGet/Set` versuchen zuerst `window.storage` (Claude-Artifact-Sandbox) und fallen sonst auf `localStorage` zurück. Damit läuft derselbe Code unverändert im Artifact **und** als deploytes Vite-Bundle.

---

## Warum diese Aufteilung

Der ursprüngliche Build war eine einzelne Datei mit ~1.900 Zeilen. Die Modularisierung verfolgt drei Ziele:

1. **Testbarkeit** — die Engine ist isoliert und deterministisch prüfbar.
2. **Erweiterbarkeit** — eine neue App ist eine Datei plus ein Eintrag in `data/apps.js` und `apps/index.jsx`.
3. **Lesbarkeit** — jede Datei passt auf einen Bildschirm-Kontext; Grenzen folgen Verantwortlichkeiten, nicht Zufall.
