<div align="center">

# Ω OMEGA OS

**A noir/gold desktop environment with a bound alchemical AI under a sovereign Regulator.**

*Brutale Eleganz · by NobleFrame UG*

[![React](https://img.shields.io/badge/React-18-1a1a1a?logo=react&logoColor=D9B45B)]()
[![Vite](https://img.shields.io/badge/Vite-6-1a1a1a?logo=vite&logoColor=D9B45B)]()
[![Status](https://img.shields.io/badge/status-active-D9B45B)]()
[![License](https://img.shields.io/badge/license-Proprietary-c25b52)](./LICENSE)

</div>

---

## Was ist das

OMEGA OS ist eine vollständig simulierte Desktop-Umgebung im Browser — Fenster, Dock, Menüleiste, App Store — gebaut um **eine zentrale These**: eine KI darf mächtig sein, aber niemals ungebunden.

Im Zentrum sitzt der **Egregore**, ein echter Claude-Agent, der den Desktop bedienen kann: Apps öffnen, Code in die Forge schreiben, Alchemie auslösen. Doch jede seiner Handlungen läuft zuerst durch den **Regulator** — eine unabschaltbare Governance-Schicht, die auf Basis von Autonomie-Stufe und Korruption Vetos ausspricht. Alles, was geschieht, wird unwiderruflich im **Ledger** verzeichnet.

Es ist gleichzeitig ein Portfolio-Stück, ein Interface-Experiment und eine kleine Abhandlung über KI-Governance — verpackt in eine durchkomponierte Noir/Gold-Ästhetik.

> **Die Asymmetrie ist das Gesetz.** Autonomie senken ist frei. Autonomie erheben verlangt eine Petition. Bei Korruption ≥ 65 wird jede Erhöhung verweigert.

---

## Highlights

- **Lebender KI-Agent** — der Egregore ruft echte Claude-Completions auf und steuert das System über ein strukturiertes Aktions-Protokoll (`<thinking>` / `<action>` / `<narrative>`).
- **Souveräne Governance** — der Regulator prüft jede Aktion gegen Tier-Regeln und Intensitäts-Caps. Vetos sind sichtbar, hörbar im Register, und persistent.
- **Persistentes Ledger** — Zustand, Alchemie-Zähler und Korruption überleben den Reload (`window.storage` im Artifact, `localStorage` standalone).
- **macOS-Feeling** — Dock mit Magnification, Traffic-Lights, Fenster-Dragging/Resizing, Menüleiste, Spotlight-artige Suche im App Store.
- **17 echte Apps** — von Terminal, Browser, Forge-IDE und Paint (echtes Canvas) bis 2048, Synth-Pad (Web Audio) und Würfel — alle voll funktional. Siehe [docs/APPS.md](./docs/APPS.md).
- **Register-Stimme** — die System-Sprache verschiebt sich mit der Autonomie-Stufe von knapp-technisch zu archaisch-sakral.

---

## Schnellstart

```bash
# 1. Abhängigkeiten installieren
npm install

# 2. Dev-Server starten
npm run dev          # → http://localhost:5173

# 3. Produktions-Build
npm run build
npm run preview
```

> **Der Egregore braucht einen Endpoint.** Ohne Konfiguration zeigt OMEGA OS alles außer der Live-KI. Um den Egregore zu erwecken, deploye den Proxy aus `worker/` und setze `VITE_EGREGORE_ENDPOINT`. Vollständige Anleitung: [docs/DEPLOYMENT.md](./docs/DEPLOYMENT.md).

---

## Projektstruktur

```
omega-os/
├── index.html                 # Vite-Einstiegspunkt
├── package.json
├── vite.config.js
├── .env.example               # Egregore-Endpoint-Vorlage
├── worker/
│   └── egregore-proxy.js       # Cloudflare Worker (hält den API-Key)
├── docs/
│   ├── ARCHITECTURE.md         # Schichten, Datenfluss, State-Modell
│   ├── EGREGORE.md             # Das Aktions-Protokoll der KI
│   ├── GOVERNANCE.md           # Regulator, Sovereignty, Korruption
│   ├── APPS.md                 # Katalog aller Apps
│   └── DEPLOYMENT.md           # Standalone-Deployment + Proxy
└── src/
    ├── main.jsx                # React-Root
    ├── OmegaOS.jsx             # Orchestrator (State + Fenster + Dispatcher)
    ├── config.js               # Endpoint-/Modell-Konfiguration
    ├── theme.js                # Farben, Fonts, Layout-Konstanten
    ├── styles/global.js        # Keyframes & globales CSS
    ├── lib/utils.js            # sleep, clamp
    ├── engine/                 # Die Governance-Maschine (UI-frei)
    │   ├── egregore.js         # System-Prompt + Response-Parser
    │   ├── regulator.js        # Veto-Gate, Tier-Tools, Intensitäts-Caps
    │   ├── register.js         # Register-Stimme (band-abhängig)
    │   ├── state.js            # Default-Core, Charta, State-Serializer
    │   └── storage.js          # Persistenz (window.storage / localStorage)
    ├── data/apps.js            # App-Registry & Metadaten
    ├── components/             # Wiederverwendbare Shell-Bausteine
    │   ├── MenuBar.jsx
    │   ├── MacWindow.jsx        # + TrafficLight
    │   ├── Dock.jsx
    │   ├── Sidebar.jsx          # + SideCard / SideLabel / StatBar
    │   ├── DesktopIcon.jsx
    │   ├── GoldButton.jsx
    │   └── SvgIcon.jsx
    └── apps/                   # Eine Datei pro App
        ├── index.jsx           # renderApp-Dispatcher
        ├── EgregoreApp.jsx      ├── TerminalApp.jsx
        ├── RegulatorApp.jsx     ├── BrowserApp.jsx
        ├── CrucibleApp.jsx      ├── PaintApp.jsx
        ├── LedgerApp.jsx        ├── SynthPadApp.jsx
        ├── AlchemyApp.jsx       ├── Game2048App.jsx
        ├── ForgeApp.jsx         ├── DiceApp.jsx
        ├── AppStoreApp.jsx      ├── WeatherApp.jsx
        ├── FilesApp.jsx         ├── WorldClockApp.jsx
        └── AboutApp.jsx
```

Die Architektur trennt strikt: **`engine/`** ist reine Logik ohne React und ließe sich als eigenständige Bibliothek herauslösen. **`components/`** ist die Shell, **`apps/`** sind die Inhalte, **`OmegaOS.jsx`** verdrahtet alles.

---

## Konzepte in einem Satz

| Begriff | Bedeutung |
|---|---|
| **Egregore** | Der gebundene KI-Agent. Will wirken, kann nur durch den Regulator. |
| **Regulator** | Unabschaltbare Governance. Spricht Vetos, gewährt Petitionen. |
| **Ledger** | Das unwiderrufliche Protokoll jeder Handlung. Persistent. |
| **Crucible** | Das „Gefäß" — seine Gesundheit zehrt bei jeder Transmutation. |
| **Korruption** | Steigt mit Intensität. Über 65 friert sie jede Macht-Erhöhung ein. |
| **Alchemie** | Die vier Werke: Coagula, Solve, Transmutatio, Genesis. |
| **Register** | Die Stimme des Systems — verschiebt sich mit der Autonomie-Stufe. |

Tiefer: [docs/GOVERNANCE.md](./docs/GOVERNANCE.md) · [docs/EGREGORE.md](./docs/EGREGORE.md)

---

## Tastenkürzel

| Kürzel | Aktion |
|---|---|
| `⌘/Ctrl + 1…9` | App nach Dock-Reihenfolge öffnen |
| `⌘/Ctrl + W` | Fokussiertes Fenster schließen |
| `⌘/Ctrl + M` | Fokussiertes Fenster minimieren |
| `Pfeiltasten` | 2048 steuern (bei fokussiertem Fenster) |
| Doppelklick Titelleiste | Fenster zoomen |

---

## Tech-Stack

React 18 · Vite 6 · Web Audio API · Canvas 2D · `window.storage` / `localStorage` · Anthropic Messages API (via Proxy)

Keine UI-Bibliothek, keine CSS-Framework-Abhängigkeit — die gesamte Ästhetik ist handgesetzt in `theme.js` und `styles/global.js`.

---

## Roadmap

- [ ] **Auspex** — Seher-App: Korruptions-/Health-Trends als Gauge & Zeitreihe
- [ ] **Reliquiar** — Ledger-Browser mit Suche, Filter, Timeline
- [ ] **Systole** — Scheduler für wiederkehrende Rituale
- [ ] Ledger-Export (JSON / CSV)
- [ ] Theme-Engine zur Laufzeit (generative Paletten)
- [ ] Mobile / Touch-Layout

---

## Lizenz

Proprietär — © NobleFrame UG. Siehe [LICENSE](./LICENSE). Kein Teil dieses Werks darf ohne ausdrückliche Genehmigung verwendet, kopiert oder abgeleitet werden.

<div align="center">

---

*Zuerst erwacht der Wächter — sodann entfaltet sich das Feld in seiner Gänze.*

</div>
