# Changelog

Alle nennenswerten Änderungen an OMEGA OS.
Format angelehnt an [Keep a Changelog](https://keepachangelog.com/).

## [4.0.0] — 2026-06

### Geändert
- **Modularisierung.** Der monolithische Einzeldatei-Build (~1.900 Zeilen) wurde in
  eine vollständige Vite-Projektstruktur aufgeteilt: Engine, Komponenten, Apps und
  Orchestrator sind jetzt getrennte Module.
- **Egregore-Endpoint konfigurierbar.** Der hartkodierte Anthropic-Aufruf liest nun
  Endpoint, Modell und Token-Limit aus `src/config.js` (`VITE_EGREGORE_*`).

### Hinzugefügt
- Cloudflare-Worker-Proxy (`worker/egregore-proxy.js`) für sichere, schlüssel-freie
  Frontend-Aufrufe.
- Vollständige Dokumentation unter `docs/` (Architektur, Egregore, Governance,
  Apps, Deployment).
- `.env.example`, `.gitignore`, proprietäre Lizenz.

### Bestand (aus v3-Monolith übernommen)
- Egregore als lebender KI-Agent mit `<thinking>`/`<action>`/`<narrative>`-Protokoll.
- Souveräner Regulator mit Tier-Tools, Intensitäts-Caps und der Asymmetrie
  (Senken frei, Erheben per Petition, Sperre ab Korruption 65).
- Persistentes Ledger, Crucible-Gesundheit, der Zeuge.
- Register-Stimme in drei autonomie-abhängigen Bändern.
- 17 voll funktionale Apps inkl. Terminal, Forge, Paint (Canvas), 2048,
  Synth-Pad (Web Audio).
- macOS-Shell: Dock mit Magnification, Traffic-Lights, Fenster-Management,
  Menüleiste, App Store mit Suche.

### Roadmap (offen)
- Auspex (Seher), Reliquiar (Ledger-Browser), Systole (Scheduler).
- Ledger-Export (JSON/CSV).
- Laufzeit-Theme-Engine.
- Mobile-/Touch-Layout.
